<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$config['status_prefix'] = '<div class="alert alert-info">';
$config['status_suffix'] = '</div>';

$config['record_creation_successful'] = 'Record Created Successfully';


#account_creation_successful
#$config['messages']['delimiters']['error_prefix']


/* End of file message_settings.php */
/* Location: ./application/config/message_settings.php */
