<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Bar_Pub_Owner extends Admin_Controller {
    function __construct() {
        parent::__construct();
        $this->load->model('admin/bar_pub_owner_model', '', TRUE);
        $this->smarty->assign("data", $this->data);
        if (!isset($this->session->userdata['happyhour_admin_info'])) {
            redirect($this->data['admin_url'] . 'authentication');
            exit;
        }
    }
    
    function index() {
        $this->data['menuAction'] = 'barOwner';
        $this->data['barpubOwenerlist'] = $this->bar_pub_owner_model->getAllBarPubOwner();
        $this->data['tpl_name'] = "admin/bar_owner/view_bar_pub_owner.tpl";
        $this->data['message'] = $this->session->flashdata('message');
        $this->data['happyhour_admin_info'] = $this->session->userdata['happyhour_admin_info'];
        $this->breadcrumb->add('Dashboard', $this->data['admin_url'] . 'home');
        $this->breadcrumb->add('View Manage Bar - Pub Owner', '');
        $this->data['breadcrumb'] = $this->breadcrumb->output();
        $this->smarty->assign('data', $this->data);
        $this->smarty->view('admin/admin-template.tpl');
    }
    
    function action_update() {
        $ids = $this->input->post('iId');
        $action = $this->input->post('action');
        $tableData['tablename'] = 'bar_owner';
        $tableData['update_field'] = 'iOwnerId';
        $count = $this->update_status($ids, $action, $tableData);
        if ($action == 'Delete') {
            $count = count($ids);
        } else {
            $count = $count;
        }
        $recordtitle = '';
        if ($count > 1) {
            $recordtitle = 'Records';
        } else {
            $recordtitle = 'Record';
        }
        if ($action == 'Delete') {
            $this->session->set_flashdata('message', "Total  ($count) " . $recordtitle . " Deleted Successfully");
        } else {
            $this->session->set_flashdata('message', "Total  ($count) " . $recordtitle . " Updated Successfully");
        }
        redirect($this->data['admin_url'] . 'bar_pub_owner');
    }

    function create() {
        $eStatuses = field_enums('bar_owner', 'eStatus');
        $eDesignation = field_enums('bar_owner', 'eDesignation');
        $this->data['action'] = 'create';
        $this->data['label'] = 'Add';
        if ($this->input->post()) {
            $bar_detail = $this->input->post();
            $password = $this->input->post('vPassword');
            $bar_detail['vPassword'] = encrypt($this->input->post('vPassword'));
            $bar_detail['dCreatedDate'] = date('Y-m-d');
            $bar_detail['eStatus'] = 'Active';

            $iOwnerId = $this->bar_pub_owner_model->add_bar_owner($bar_detail);
            
            $this->session->set_flashdata('message', "Manage Bar - Pub Owner Added Successfully");
            redirect($this->data['admin_url'] . 'bar_pub_owner');
            exit;
        }
        $this->breadcrumb->add('Dashboard', $this->data['admin_url'] . 'home');
        $this->breadcrumb->add('View Manage Bar - Pub Owner', $this->data['admin_url'] . "bar_pub_owner");
        $this->breadcrumb->add('Add Manage Bar - Pub Owner', '');
        $this->data['breadcrumb'] = $this->breadcrumb->output();
        $this->data['tpl_name'] = "admin/bar_owner/add_edit_bar_pub_owner.tpl";
        $this->smarty->assign('data', $this->data);
        $this->smarty->assign('eStatuses', $eStatuses);
        $this->smarty->assign('eDesignation', $eDesignation);
        $this->smarty->view('admin/admin-template.tpl');
    }
    
    function update() {
        $eStatuses = field_enums('bar_owner', 'eStatus');
        $eDesignation = field_enums('bar_owner', 'eDesignation');
        $this->data['action'] = 'update';
        $this->data['label'] = 'Edit';
        $iOwnerId = $this->uri->segment(4);
        $this->data['barOwnerDetail'] = $this->bar_pub_owner_model->getBarOwnerDetails($iOwnerId);
        if ($this->input->post()) {
            $bar_detail = $this->input->post();
            $bar_detail['dModifiedDate'] = date('Y-m-d');
            
            $iOwnerId = $this->bar_pub_owner_model->edit_bar_owner($bar_detail);
            $this->session->set_flashdata('message', "Manage Bar - Pub Owner Details Updated Successfully");
            redirect($this->data['admin_url'] . 'bar_pub_owner');
            exit;
        }
        $this->breadcrumb->add('Dashboard', $this->data['admin_url'] . 'home');
        $this->breadcrumb->add('View Manage Bar - Pub Owner', $this->data['admin_url'] . "bar_pub_owner");
        $this->breadcrumb->add('Edit Manage Bar - Pub Owner', '');
        $this->data['breadcrumb'] = $this->breadcrumb->output();
        $this->data['tpl_name'] = "admin/bar_owner/add_edit_bar_pub_owner.tpl";
        $this->smarty->assign('data', $this->data);
        $this->smarty->assign('eStatuses', $eStatuses);
        $this->smarty->assign('eDesignation', $eDesignation);
        $this->smarty->view('admin/admin-template.tpl');
    }

    function check_email_exist() {
        $vEmail = $this->input->get('email');
        $db_admin_email = $this->input->get('oldemail');
        if ($vEmail == $db_admin_email) {
            echo "sucess";
        } else {
            $checkexist = $this->bar_pub_owner_model->admin_exists($vEmail);
            if ($checkexist != 0) {
                echo "exitst";
            } else {
                echo "Not exitst";
            }
            exit;
        }
    }
}
?>