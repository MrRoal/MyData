<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Bar extends Admin_Controller {
    function __construct() {
        parent::__construct();
        $this->load->model('admin/bar_model', '', TRUE);
        $this->smarty->assign("data", $this->data);
        if (!isset($this->session->userdata['happyhour_admin_info'])) {
            redirect($this->data['admin_url'] . 'authentication');
            exit;
        }
    }
    
    function index() {
        $this->data['menuAction'] = 'manageBar';
        $this->data['barpubOwenerlist'] = $this->bar_model->getAllBarPubOwner();
        $this->data['tpl_name'] = "admin/bar/view_bar.tpl";
        $this->data['message'] = $this->session->flashdata('message');
        $this->data['happyhour_admin_info'] = $this->session->userdata['happyhour_admin_info'];
        $this->breadcrumb->add('Dashboard', $this->data['admin_url'] . 'home');
        $this->breadcrumb->add('View Bar - Pub', '');
        $this->data['breadcrumb'] = $this->breadcrumb->output();
        $this->smarty->assign('data', $this->data);
        $this->smarty->view('admin/admin-template.tpl');
    }
    
    function action_update() {
        $ids = $this->input->post('iId');
        $action = $this->input->post('action');
        $tableData['tablename'] = 'bar_owner';
        $tableData['update_field'] = 'iOwnerId';
        $count = $this->update_status($ids, $action, $tableData);
        if ($action == 'Delete') {
            $count = count($ids);
        } else {
            $count = $count;
        }
        $recordtitle = '';
        if ($count > 1) {
            $recordtitle = 'Records';
        } else {
            $recordtitle = 'Record';
        }
        if ($action == 'Delete') {
            $this->session->set_flashdata('message', "Total  ($count) " . $recordtitle . " Deleted Successfully");
        } else {
            $this->session->set_flashdata('message', "Total  ($count) " . $recordtitle . " Updated Successfully");
        }
        redirect($this->data['admin_url'] . 'bar');
    }

    function create() {
        $this->data['menuAction'] = 'manageBar';
        $eStatuses = field_enums('bar_owner', 'eStatus');
        $eDesignation = field_enums('bar_owner', 'eDesignation');
        $eFeatured = field_enums('bar', 'eFeatured');
        $barOweners = $this->bar_model->getAllBarPubOwner();
        // echo "<pre>";print_r($barOweners); echo "</pre>";exit;
        $this->data['action'] = 'create';
        $this->data['label'] = 'Add';
        if ($this->input->post()) {
           // echo "<pre>"; print_r($this->input->post());exit;
            $bar_detail = $this->input->post();
            $iOwnerId = $this->bar_model->add_bar($bar_detail);
            
            $this->session->set_flashdata('message', "Bar - Pub Added Successfully");
            redirect($this->data['admin_url'] . 'bar');
            exit;
        }
        $this->breadcrumb->add('Dashboard', $this->data['admin_url'] . 'home');
        $this->breadcrumb->add('View Bar - Pub', $this->data['admin_url'] . "bar");
        $this->breadcrumb->add('Add Bar - Pub', '');
        $this->data['breadcrumb'] = $this->breadcrumb->output();
        $this->data['tpl_name'] = "admin/bar/add_edit_bar.tpl";
        $this->smarty->assign('data', $this->data);
        $this->smarty->assign('barOweners', $barOweners);
        $this->smarty->assign('eStatuses', $eStatuses);
        $this->smarty->assign('eFeatured', $eFeatured);
        $this->smarty->assign('eDesignation', $eDesignation);
        $this->smarty->view('admin/admin-template.tpl');
    }
    
    function update() {
        $eStatuses = field_enums('bar_owner', 'eStatus');
        $eDesignation = field_enums('bar_owner', 'eDesignation');
        $this->data['barOweners'] = $this->bar_model->getAllBarPubOwner();
        $this->data['action'] = 'update';
        $this->data['label'] = 'Edit';
        $iOwnerId = $this->uri->segment(4);
        $this->data['barOwnerDetail'] = $this->bar_model->getBarOwnerDetails($iOwnerId);
        if ($this->input->post()) {
            $bar_detail = $this->input->post('bar_detail');
            $bar_detail['iOwnerId'] = $this->input->post('iOwnerId');
            $bar_detail['vFirstName'] = $bar_detail['vFirstName'];
            $bar_detail['vLastName'] = $bar_detail['vLastName'];
            $bar_detail['vEmail'] = $bar_detail['vEmail'];
            $bar_detail['iMobileNo'] = $bar_detail['iMobileNo'];
            $bar_detail['eDesignation'] = $bar_detail['eDesignation'];
            $bar_detail['dModifiedDate'] = date('Y-m-d');
            $bar_detail['eStatus'] = $bar_detail['eStatus'];
            
            $iOwnerId = $this->bar_model->edit_bar_owner($bar_detail);
            $this->session->set_flashdata('message', "Bar - Pub Details Updated Successfully");
            redirect($this->data['admin_url'] . 'bar');
            exit;
        }
        $this->breadcrumb->add('Dashboard', $this->data['admin_url'] . 'home');
        $this->breadcrumb->add('View Bar - Pub', $this->data['admin_url'] . "bar");
        $this->breadcrumb->add('Edit Bar - Pub', '');
        $this->data['breadcrumb'] = $this->breadcrumb->output();
        $this->data['tpl_name'] = "admin/bar/add_edit_bar.tpl";
        $this->smarty->assign('data', $this->data);
        $this->smarty->assign('eStatuses', $eStatuses);
        $this->smarty->assign('eDesignation', $eDesignation);
        $this->smarty->view('admin/admin-template.tpl');
    }

    function check_email_exist() {
        $vEmail = $this->input->get('email');
        $db_admin_email = $this->input->get('oldemail');
        if ($vEmail == $db_admin_email) {
            echo "sucess";
        } else {
            $checkexist = $this->bar_model->admin_exists($vEmail);
            if ($checkexist != 0) {
                echo "exitst";
            } else {
                echo "Not exitst";
            }
            exit;
        }
    }
}
?>