<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Static_page extends Admin_Controller {
    function __construct() {
        parent::__construct();
        $this->load->model('admin/staticpage_model', '', TRUE);
        if (!isset($this->session->userdata['ridein_admin_info'])) {
            redirect($this->data['admin_url'] . 'authentication');
            exit;
        }
        $this->smarty->assign("data", $this->data);
    }
    function index() {
        $this->data['tpl_name'] = "admin/static_page/view-staticpage.tpl";
        $upload_path = $this->config->item('base_path');
        $this->data['message'] = $this->session->flashdata('message');
        $this->data['ridein_admin_info'] = $this->session->userdata['ridein_admin_info'];
        $this->breadcrumb->add('Dashboard', $this->data['admin_url'] . 'home');
        $this->breadcrumb->add('View Static Page', '');
        $this->data['breadcrumb'] = $this->breadcrumb->output();
        $this->smarty->assign('data', $this->data);
        $this->smarty->view('admin/admin_template.tpl');
    }
    function action_update() {
        $ids = $this->input->post('iId');
        $action = $this->input->post('action');
        $tableData['tablename'] = 'static_pages';
        $tableData['update_field'] = 'iSPageId';
        $count = $this->update_status($ids, $action, $tableData);
        if ($action == 'Delete') {
            $count = count($ids);
        } else {
            $count = $count;
        }
        $recordtitle = '';
        if ($count > 1) {
            $recordtitle = 'Records';
        } else {
            $recordtitle = 'Record';
        }
        if ($action == 'Delete') {
            $this->session->set_flashdata('message', "Total  ($count) " . $recordtitle . " Deleted Successfully");
        } else {
            $this->session->set_flashdata('message', "Total  ($count) " . $recordtitle . " Updated Successfully");
        }
        redirect($this->data['admin_url'] . 'static_page');
    }
    function create() {
        $eStatuses = field_enums('static_pages', 'eStatus');
        $totalRec = $this->staticpage_model->count_all();
        $this->data['totalRec'] = $totalRec['tot'];
        $this->data['initOrder'] = 1;
        $this->data['action'] = 'create';
        $this->data['label'] = 'Add';
        if ($this->input->post()) {
            //echo "<pre>";print_r($_REQUEST);exit;
            $spage = $this->input->post('page');
            $spage['tContent_en'] = stripslashes($_REQUEST['page']['tContent_en']);
            $spage['dAddedDate'] = date("Y-m-d");
            $iSPageId = $this->staticpage_model->add_staticpage($spage);
            $this->session->set_flashdata('message', "Static Page Added Successfully");
            redirect($this->data['admin_url'] . 'static_page');
            exit;
        }
        $this->breadcrumb->add('Dashboard', $this->data['admin_url'] . 'home');
        $this->breadcrumb->add('View Static Page', $this->data['admin_url'] . "static_page");
        $this->breadcrumb->add('Add Static Page', '');
        $this->data['breadcrumb'] = $this->breadcrumb->output();
        $this->data['tpl_name'] = "admin/static_page/static_page.tpl";
        $this->smarty->assign('data', $this->data);
        $this->smarty->assign('eStatuses', $eStatuses);
        $this->smarty->view('admin/admin_template.tpl');
    }
    function update() {
        $eStatuses = field_enums('static_pages', 'eStatus');
        $this->data['action'] = 'update';
        $this->data['label'] = 'Edit';
        $iSPageId = $this->uri->segment(4);
        $totalRec = $this->staticpage_model->count_all();
        $this->data['totalRec'] = $totalRec['tot'];
        $this->data['initOrder'] = 1;
        $this->data['page'] = $this->staticpage_model->get_staticpage_details($iSPageId);
        if ($this->input->post()) {
            $spage = $this->input->post('page');
            $spage['dAddedDate'] = date("Y-m-d");
            $spage['tContent_en'] = stripslashes($_REQUEST['page']['tContent_en']);
            //echo "<pre>";print_r($spage);exit;
            $iSPageId = $this->input->post('iSPageId');
            $spage['iSPageId'] = $iSPageId;
            $iSPageId = $this->staticpage_model->edit_staticpage($spage);
            $this->session->set_flashdata('message', "Static Page Updated Successfully");
            redirect($this->data['admin_url'] . 'static_page');
            exit;
        }
        $this->breadcrumb->add('Dashboard', $this->data['admin_url'] . 'home');
        $this->breadcrumb->add('View Static Page', $this->data['admin_url'] . "static_page");
        $this->breadcrumb->add('Edit Static Page', '');
        $this->data['breadcrumb'] = $this->breadcrumb->output();
        $this->data['tpl_name'] = "admin/static_page/static_page.tpl";
        $this->smarty->assign('data', $this->data);
        $this->smarty->assign('eStatuses', $eStatuses);
        $this->smarty->view('admin/admin_template.tpl');
    }
    function get_static_page_listing() {
        $all_page = $this->staticpage_model->get_staticpage();
        if (count($all_page) > 0) {
            foreach ($all_page as $key => $value) {
                $alldata[$key]['id'] = '<center><input type="checkbox" name="iId[]" id="iId" value="' . $value['iSPageId'] . '"></center>';
                $alldata[$key]['vPageTitle'] = ucwords($value['vPageTitle']);
                $alldata[$key]['vPageName'] = $value['vPageName'];
                $alldata[$key]['tContent_en'] = $value['tContent_en'];
                $alldata[$key]['iOrderNo'] = $value['iOrderNo'];
                $alldata[$key]['dAddedDate'] = $value['dAddedDate'];
                $alldata[$key]['eStatus'] = $value['eStatus'];
                $alldata[$key]['editlink'] = '<center><a href="' . $this->data['base_url'] . 'static_page/update/' . $value['iSPageId'] . '"><i class="icon-pen icon2x"></i></a></center>';
            }
            $aData['aaData'] = $alldata;
        } else {
            $aData['aaData'] = '';
        }
        $json_lang = json_encode($aData);
        echo $json_lang;
        exit;
    }
}
/* End of file static_page.php */
/* Location: ./application/controllers/static_page.php */
?>