<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class User extends Admin_Controller {
    function __construct() {
        parent::__construct();
        $this->load->model('admin/user_model', '', TRUE);
        if (!isset($this->session->userdata['happyhour_admin_info'])) {
            redirect($this->data['admin_url'] . 'authentication');
            exit;
        }
        $this->smarty->assign("data", $this->data);
    }
    
    //load user listing
    function index() {
        $this->data['menuAction'] = 'manageUser';
        $this->data['userlist'] = $this->user_model->getAllUserList();
        $this->data['tpl_name'] = "admin/user/view_user.tpl";
        $this->data['message'] = $this->session->flashdata('message');
        $this->breadcrumb->add('Dashboard', $this->data['admin_url'] . 'home');
        $this->breadcrumb->add('View Users', '');
        $this->data['breadcrumb'] = $this->breadcrumb->output();
        $this->smarty->assign('data', $this->data);
        $this->smarty->view('admin/admin-template.tpl');
    }
    
    //create user
    function create() {
        $this->data['menuAction'] = 'manageUser';
        $eStatuses = field_enums('users', 'eStatus');
        $eRole = field_enums('users', 'eRole');
        $eGender = field_enums('users', 'eGender');
        $this->data['action'] = 'create';
        $this->data['label'] = 'Add';
        if ($this->input->post()) {
            /*echo"<pre>";print_r($this->input->post());
            print_r($_FILES);
            exit;*/
            $user = $this->input->post();
            $user['vPassword'] = encrypt($this->input->post('vPassword'));
            $user['dBirthDate'] = date('Y-m-d',strtotime($this->input->post('dBirthDate')));
            $user['dCreatedDate'] = date('Y-m-d');
            $user['eStatus'] = 'Active';
            $iUserId = $this->user_model->add_user($user);
            
            if ($_FILES['vProfilePicture']['name'] != '') {
                $size = array();
                $user['vProfilePicture'] = $_FILES['vProfilePicture']['name'];
                $image_uploaded = $this->do_upload_img($iUserId, 'user', 'vProfilePicture', $size);
                $user['vProfilePicture'] = $image_uploaded;
                $user['iUserId'] = $iUserId;

                $iUserId = $this->user_model->edit_user($user);
            }
            $this->session->set_flashdata('message', "Client added successfully");
            redirect($this->data['admin_url'] . 'user');
            exit;
        }
        $this->breadcrumb->add('Dashboard', $this->data['admin_url'] . 'home');
        $this->breadcrumb->add('View Users', $this->data['admin_url'] . "user");
        $this->breadcrumb->add('Add User', '');
        $this->data['breadcrumb'] = $this->breadcrumb->output();
        $this->data['tpl_name'] = "admin/user/add_edit_user.tpl";
        $this->smarty->assign('eStatuses', $eStatuses);
        $this->smarty->assign('eRole', $eRole);
        $this->smarty->assign('eGender', $eGender);
        $this->smarty->assign('data', $this->data);
        $this->smarty->view('admin/admin-template.tpl');
    }
    
    //update user
    function update() {
        $this->data['menuAction'] = 'manageUser';
        $this->data['action'] = 'update';
        $this->data['label'] = 'Edit';
        $eStatuses = field_enums('users', 'eStatus');
        $eRole = field_enums('users', 'eRole');
        $eGender = field_enums('users', 'eGender');
        $iUserId = $this->uri->segment(4);
        $this->data['user_detail'] = $this->user_model->get_user_details($iUserId);
        $this->data['user']['vPassword'] = $this->decrypt($this->data['user']['vPassword']);
        
        if ($this->input->post()) {
            
            $user = $this->input->post();
            $user['dBirthDate'] = date('Y-m-d',strtotime($this->input->post('dBirthDate')));
            $user['dModifiedDate'] = date('Y-m-d');
            
            if ($_FILES['vProfilePicture']['name'] != '') {
                $iUserId = $this->input->post('iUserId');
                $size = array();
                $user['vProfilePicture'] = $_FILES['vProfilePicture']['name'];
                $image_uploaded = $this->do_upload_img($iUserId, 'user', 'vProfilePicture', $size);
                $user['vProfilePicture'] = $image_uploaded;
               
            }

            $iUserId = $this->user_model->edit_user($user);
           
            $this->session->set_flashdata('message', "User updated successfully");
            redirect($this->data['admin_url'] . 'user');
            exit;
        }
        $this->breadcrumb->add('Dashboard', $this->data['admin_url'] . 'home');
        $this->breadcrumb->add('View Users', $this->data['admin_url'] . "user");
        $this->breadcrumb->add('Edit User', '');
        $this->data['breadcrumb'] = $this->breadcrumb->output();
        $this->data['tpl_name'] = "admin/user/add_edit_user.tpl";
        $this->smarty->assign('data', $this->data);
        $this->smarty->assign('eStatuses', $eStatuses);
        $this->smarty->assign('iUserId', $iUserId);
        $this->smarty->assign('eRole', $eRole);
        $this->smarty->assign('eGender', $eGender);
        $this->smarty->view('admin/admin-template.tpl');
    }
    //update status
    function action_update() {
        $ids = $this->input->post('iId');
        $action = $this->input->post('action');
        $tableData['tablename'] = 'users';
        $tableData['update_field'] = 'iUserId';
        $tableData['image_field'] = 'vProfilePicture';
        $tableData['folder_name'] = 'users';
        $count = $this->update_status($ids, $action, $tableData);
        if ($action == 'Delete') {
            $count = count($ids);
        } else {
            $count = $count;
        }
        if ($action == 'Delete') {
            $this->session->set_flashdata('message', "Total  ($count) " . $recordtitle . " Deleted Successfully");
        } else {
            $this->session->set_flashdata('message', "Total  ($count) " . $recordtitle . " Updated Successfully");
        }
        redirect($this->data['admin_url'] . 'user');
    }
    // get all states
    function get_all_states() {
        $iUserId = $this->uri->segment(4);
        $states = $this->user_model->get_states($iUserId);
        $options = '';
        if (count($states) > 0) {
            $options.= '<option value="">-- Select State--</option>';
            for ($i = 0;$i < count($states);$i++) {
                $options.= '<option value="' . $states[$i]['iStateId'] . '">' . $states[$i]['vState'] . '</option>';
            }
        } else {
            $options.= '<option value="">-- Select State--</option>';
        }
        $json_lang = json_encode($options);
        print $json_lang;
        exit;
    }
    //delete images
    function deleteicon() {
        $upload_path = $this->config->item('base_path');
        $iUserId = $this->input->get('id');
        $crop_imag = array();
        $crop_imag['image1'] = '160X180_';
        $crop_imag['image2'] = '42X37_';
        $tableData['tablename'] = 'user';
        $tableData['update_field'] = 'iUserId';
        $tableData['image_field'] = 'vProfileImage';
        $tableData['crop_image'] = $crop_imag;
        $tableData['folder_name'] = 'user';
        $tableData['field_id'] = $iUserId;
        $deleteImage = $this->delete_image($tableData);
        redirect($this->data['admin_url'] . 'user/update/' . $iUserId);
    }
   
    function check_username() {
        $email = $this->input->get('email');
        $db_user_email = $this->input->get('db_user_email');
        if ($db_user_email == $email) {
            echo "sucess";
        } else {
            $getUserDetail = $this->user_model->getuser_by_mail($email);
            if (count($getUserDetail) > 0) {
                echo "exitst";
                exit;
            } else {
                echo "sucess";
                exit;
            }
        }
    }
    
    // get all cities
    function get_all_cities() {
        $iStateId = $this->input->get('iStateId');
        $iCountryId = $this->input->get('iCountryId');
        $states = $this->user_model->get_cities($iCountryId, $iStateId);
        $options = '';
        if (count($states) > 0) {
            $options.= '<option value="">-- Select city--</option>';
            for ($i = 0;$i < count($states);$i++) {
                $options.= '<option value="' . $states[$i]['iCityId'] . '">' . $states[$i]['vCity'] . '</option>';
            }
        } else {
            $options.= '<option value="">-- Select city--</option>';
        }
        $json_lang = json_encode($options);
        print $json_lang;
        exit;
    }

    function exportToExcel(){
        $allUsers = $this->user_model->getAllExportUsers();
        $this->data['menuAction'] = 'User';
        
        /*echo "<pre>";print_r($allUsers);exit;*/
        $acticodestr =array();
        for($i=0;$i<count($allUsers);$i++){
            $acticodestr[$i]['Name'] = $allUsers[$i]['vFirstName'].' '.$allUsers[$i]['vLastName'];
            $acticodestr[$i]['Email']=$allUsers[$i]['vEmail'];
            $acticodestr[$i]['Contact Number']=$allUsers[$i]['iMobileNo'];
            $acticodestr[$i]['Date Of Birth']=$allUsers[$i]['dBirthDate'];
            $acticodestr[$i]['Gender']=$allUsers[$i]['eGender'];
            $acticodestr[$i]['Join Date']=$allUsers[$i]['dCreatedDate'];
            $acticodestr[$i]['User Type']=$allUsers[$i]['eRole'];
            $acticodestr[$i]['Status']=$allUsers[$i]['eStatus'];
        }
        $date=date('Ymd');
        $filename='Users_List_'.$date.'.xls';
        // For excel
        header("Content-Disposition: attachment; filename=\"$filename\"");
        header("Content-Type: application/vnd.ms-excel");
        
        $flag = false;
        if(count($acticodestr) > 0){
            foreach($acticodestr as $row) {
                if(!$flag) {
                    // display field/column names as first row
                    echo implode("\t", array_keys($row)) . "\r\n";
                    $flag = true;
                }
                array_walk($row, 'cleanData');
                echo implode("\t", array_values($row)) . "\r\n";
            }
        }
        //redirect($this->data['admin_url'].'admin/users');
        exit;
    }
}
/* End of file user.php */
/* Location: ./application/controllers/user.php */
?>