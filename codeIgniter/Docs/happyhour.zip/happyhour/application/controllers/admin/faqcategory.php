<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Faqcategory extends Admin_Controller {
    function __construct() {
        parent::__construct();
        $this->load->model('admin/faqcategory_model', '', TRUE);
        $this->smarty->assign("data", $this->data);
        if (!isset($this->session->userdata['happyhour_admin_info'])) {
            redirect($this->data['admin_url'] . 'authentication');
            exit;
        }
    }

    //create Faqcategory
    function index() {
        $this->data['menuAction'] = 'FaqCategory';
        $this->data['faqlist'] = $this->faqcategory_model->get_all_faqcategory();
        $this->data['tpl_name'] = "admin/faq_category/view_faq_category.tpl";
        $this->data['message'] = $this->session->flashdata('message');
        $this->breadcrumb->add('Dashboard', $this->data['admin_url'] . 'home');
        $this->breadcrumb->add('View Users', '');
        $this->data['breadcrumb'] = $this->breadcrumb->output();
        $this->smarty->assign('data', $this->data);
        $this->smarty->view('admin/admin-template.tpl');
    }

    //Faqcategory active,inactive, delete
    function action_update() {
        $this->data['menuAction'] = 'FaqCategory';
        $ids = $this->input->post('iId');
        $action = $this->input->post('action');
        $tableData['tablename'] = 'faq_category';
        $tableData['update_field'] = 'iFaqcaTegoryId';
        $tableData['image_field'] = 'vImage';
        $tableData['folder_name'] = 'category_icon';
        $count = $this->update_status($ids, $action, $tableData);
        if ($action == 'Delete') {
            $count = count($ids);
        } else {
            $count = $count;
        }
        $recordtitle = '';
        if ($count > 1) {
            $recordtitle = 'Records';
        } else {
            $recordtitle = 'Record';
        }
        if ($action == 'Delete') {
            $this->session->set_flashdata('message', "Total  ($count) " . $recordtitle . " Deleted Successfully");
        } else {
            $this->session->set_flashdata('message', "Total  ($count) " . $recordtitle . " Updated Successfully");
        }
        redirect($this->data['admin_url'] . 'faqcategory');
    }
    
    //create Faqcategory
    function create() {
        $this->data['menuAction'] = 'FaqCategory';
        $eStatuses = field_enums('faq_category', 'eStatus');
        $this->data['action'] = 'create';
        $this->data['label'] = 'Add';
        if ($this->input->post()) {
            $faq['vFaqCategoryName'] = $this->input->post('vFaqCategoryName');
            $faq['eStatus'] = 'Active';
            $iFaqCategoryId = $this->faqcategory_model->add_faqcategory($faq);
           /* print_r($_FILES['vCategoryImage']['name']);exit;*/
            /*if ($_FILES['vCategoryImage']['name'] != '') {
                $size = array();
                $categoryImage['vCategoryImage'] = $_FILES['vCategoryImage']['name'];
                $image_uploaded = $this->do_upload_img($iFaqCategoryId, 'category_icon', 'vCategoryImage', $size);
                $vImage['vImage'] = $image_uploaded;
                $vImage['iFaqCategoryId'] = $iFaqCategoryId;
                $updateId = $this->faqcategory_model->edit_faqcategory($vImage);
            }*/

            $this->session->set_flashdata('message', "FAQ added successfully");
            redirect($this->data['admin_url'] . 'faqcategory');
            exit;
        }
        $this->breadcrumb->add('Dashboard', $this->data['admin_url'] . 'home');
        $this->breadcrumb->add('View FAQs Category', $this->data['admin_url'] . "faqcategory");
        $this->breadcrumb->add('Add FAQs', '');
        $this->data['breadcrumb'] = $this->breadcrumb->output();
        $this->data['tpl_name'] = "admin/faq_category/add-edit-faqcategory.tpl";
        $this->smarty->assign('eStatuses', $eStatuses);
        $this->smarty->assign('data', $this->data);
        $this->smarty->view('admin/admin-template.tpl');
    }
    //udpate Faqcategory
    function update() {
        $this->data['menuAction'] = 'FaqCategory';
        $eStatuses = field_enums('faq_category', 'eStatus');
        $this->data['action'] = 'update';
        $this->data['label'] = 'Edit';
        $iFaqcaTegoryId = $this->uri->segment(4);
        $this->data['faqcategory'] = $this->faqcategory_model->get_faqcategory_details($iFaqcaTegoryId);
        if ($this->input->post()) {
            

            $faqcategory['vFaqCategoryName'] = ucfirst($this->input->post('vFaqCategoryName'));
            $faqcategory['iFaqCategoryId'] = $this->input->post('iFaqCategoryId');
            $faqcategory['eStatus'] = $this->input->post('eStatus');
            /*if ($_FILES['vCategoryImage']['name'] != '') {
                $iFaqCategoryId=$faqcategory['iFaqCategoryId'];
                $size = array();
                $categoryImage['vCategoryImage'] = $_FILES['vCategoryImage']['name'];
                $image_uploaded = $this->do_upload_img($iFaqCategoryId, 'category_icon', 'vCategoryImage', $size);
                $faqcategory['vImage'] = $image_uploaded;
            }*/
            
            $iFaqcaTegoryId = $this->faqcategory_model->edit_faqcategory($faqcategory);
            $this->session->set_flashdata('message', "FAQs Category Updated Successfully");
            redirect($this->data['admin_url'] . 'faqcategory');
            exit;
        }
        $this->breadcrumb->add('Dashboard', $this->data['admin_url'] . 'home');
        $this->breadcrumb->add('View FAQs Category', $this->data['admin_url'] . "faqcategory");
        $this->breadcrumb->add('Edit FAQs', '');
        $this->data['breadcrumb'] = $this->breadcrumb->output();
        $this->data['tpl_name'] = "admin/faq_category/add-edit-faqcategory.tpl";
        $this->smarty->assign('data', $this->data);
        $this->smarty->assign('eStatuses', $eStatuses);
        $this->smarty->view('admin/admin-template.tpl');
    }
    function check_faqcategory() {
        $Faqcategoryname = $this->input->get('faqCategoryName');
        $faqcategory = ucfirst($Faqcategoryname);
        $faqcategoryexist = $this->faqcategory_model->faqcategory_exists($faqcategory);
        $name = count($faqcategoryexist);
        echo $name;
        exit;
    }
    function deleteicon() {
        $upload_path = $this->config->item('base_path');
        $iFaqCategoryId = $this->input->get('id');
        $tableData['tablename'] = 'faq_category';
        $tableData['update_field'] = 'iFaqCategoryId';
        $tableData['image_field'] = 'vImage';
        $tableData['folder_name'] = 'category_icon';
        $tableData['field_id'] = $iFaqCategoryId;
        $deleteImage = $this->delete_image($tableData);
        redirect($this->data['admin_url'] . 'faqcategory/update/' . $iFaqCategoryId);
    }
}
?>