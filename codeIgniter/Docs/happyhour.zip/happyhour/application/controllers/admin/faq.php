<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Faq extends Admin_Controller {
    function __construct() {
        parent::__construct();
        $this->load->model('admin/faq_model', '', TRUE);
        $this->smarty->assign("data", $this->data);
        if (!isset($this->session->userdata['happyhour_admin_info'])) {
            redirect($this->data['admin_url'] . 'authentication');
            exit;
        }
    }
    //create Faq
    function index() {
        $this->data['menuAction'] = 'Faq';
        $this->data['faqsList']=$this->faq_model->getallFaqs();
        $this->data['tpl_name'] = "admin/faq/view_faq.tpl";
        $this->data['message'] = $this->session->flashdata('message');
        $this->data['happyhour_admin_info'] = $this->session->userdata['happyhour_admin_info'];
        $this->breadcrumb->add('Dashboard', $this->data['admin_url'] . 'home');
        $this->breadcrumb->add('View FAQs', '');
        $this->data['breadcrumb'] = $this->breadcrumb->output();
        $this->smarty->assign('data', $this->data);
        $this->smarty->view('admin/admin-template.tpl');
    }
    
    //create Faq active,inactive
    function action_update() {
        $this->data['menuAction'] = 'Faq';
        $ids = $this->input->post('iId');
        $action = $this->input->post('action');
        $tableData['tablename'] = 'faq';
        $tableData['update_field'] = 'iFaqId';
        $count = $this->update_status($ids, $action, $tableData);
        if ($action == 'Delete') {
            $count = count($ids);
        } else {
            $count = $count;
        }
        $recordtitle = '';
        if ($count > 1) {
            $recordtitle = 'Records';
        } else {
            $recordtitle = 'Record';
        }
        if ($action == 'Delete') {
            $this->session->set_flashdata('message', "Total  ($count) " . $recordtitle . " Seleted Successfully");
        } else {
            $this->session->set_flashdata('message', "Total  ($count) " . $recordtitle . " Updated Successfully");
        }
        redirect($this->data['admin_url'] . 'faq');
    }
    
    //create Faq
    function create() {
        $this->data['menuAction'] = 'Faq';
        $eStatuses = field_enums('faq', 'eStatus');
        $this->data['action'] = 'create';
        $this->data['label'] = 'Add';
        $this->data['category'] = $this->faq_model->get_all_faqcategory();
        if ($this->input->post()) {
            $faq = $this->input->post();
           // print_r($this->input->post());exit;
            $iFaqcaTegoryId = $this->faq_model->add_faq($faq);
            $this->session->set_flashdata('message', "FAQs Added Successfully");
            redirect($this->data['admin_url'] . 'faq');
            exit;
        }
        $this->breadcrumb->add('Dashboard', $this->data['admin_url'] . 'home');
        $this->breadcrumb->add('View FAQS', $this->data['admin_url'] . "faq");
        $this->breadcrumb->add('Add FAQ', '');
        $this->data['breadcrumb'] = $this->breadcrumb->output();
        $this->data['tpl_name'] = "admin/faq/faq.tpl";
        $this->smarty->assign('data', $this->data);
        $this->smarty->assign('eStatuses', $eStatuses);
        $this->smarty->view('admin/admin-template.tpl');
    }
    
    //udpate Faq
    function update() {
        $this->data['menuAction'] = 'Faq';
        $eStatuses = field_enums('faq', 'eStatus');
        $this->data['action'] = 'update';
        $this->data['label'] = 'Edit';
        $iFaqId = $this->uri->segment(4);
        $this->data['faq'] = $this->faq_model->get_faq_details($iFaqId);
        if ($this->input->post()) {
            $faq = $this->input->post();
            $faq['iFaqId'] = $this->input->post('iFaqId');
            $iFaqcaTegoryId = $this->faq_model->edit_faq($faq);
            $this->session->set_flashdata('message', "FAQs Updated Successfully");
            redirect($this->data['admin_url'] . 'faq');
            exit;
        }
        $this->data['category'] = $this->faq_model->get_all_faqcategory();
        $this->breadcrumb->add('Dashboard', $this->data['admin_url'] . 'home');
        $this->breadcrumb->add('View FAQS', $this->data['admin_url'] . "faq");
        $this->breadcrumb->add('Edit FAQ', '');
        $this->data['breadcrumb'] = $this->breadcrumb->output();
        $this->data['tpl_name'] = "admin/faq/faq.tpl";
        $this->smarty->assign('data', $this->data);
        $this->smarty->assign('eStatuses', $eStatuses);
        $this->smarty->view('admin/admin-template.tpl');
    }
    
    //get Faq
    function get_faq_listing() {
        $all_faq = $this->faq_model->get_all_faq();
        //echo "<pre>";print_r($all_faq);exit;
        if (count($all_faq) > 0) {
            foreach ($all_faq as $key => $value) {
                $alldata[$key]['id'] = '<center><input type="checkbox" name="iId[]" id="iId" value="' . $value['iFaqId'] . '"></center>';
                $alldata[$key]['faqname'] = $value['vFaqCategoryName'];
                $alldata[$key]['question'] = $value['vQuestion'];
                $alldata[$key]['status'] = $value['eStatus'];
                $alldata[$key]['editlink'] = '<center><a href="' . $this->data['base_url'] . 'faq/update/' . $value['iFaqId'] . '"><i class="icon-pen icon2x"></i></a></center>';
            }
            $aData['aaData'] = $alldata;
        } else {
            $aData['aaData'] = '';
        }
        $json_lang = json_encode($aData);
        echo $json_lang;
        exit;
    }
    function check_faq() {
        $Faqname = $this->uri->segment(4);
        $faq = ucfirst($Faqname);
        $faqexist = $this->faq_model->faq_exists($faq);
        $name = count($faqexist);
        echo $name;
        exit;
    }
}
?>