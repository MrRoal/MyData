<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Contact_us extends Admin_Controller {
    function __construct() {
        parent::__construct();
        $this->load->model('admin/contact_us_model', '', TRUE);
        if (!isset($this->session->userdata['happyhour_admin_info'])) {
            redirect($this->data['admin_url'] . 'authentication');
            exit;
        }
        $this->smarty->assign("data", $this->data);
    }
    //load user listing
    function index() {
        $this->data['menuAction'] = 'ContactUs';
        $this->data['tpl_name'] = "admin/contact_us/view_contact_us.tpl";
        $this->data['message'] = $this->session->flashdata('message');
        $this->data['happyhour_admin_info'] = $this->session->userdata['happyhour_admin_info'];
        $this->breadcrumb->add('Dashboard', $this->data['admin_url'] . 'home');
        $this->breadcrumb->add('View Contact', '');
        $this->data['breadcrumb'] = $this->breadcrumb->output();
        $this->smarty->assign('data', $this->data);
        $this->smarty->view('admin/admin-template.tpl');
    }

    //create contact
     function create() {

        $this->data['action'] = 'create';
        $this->data['label'] = 'Add';
        if ($this->input->post()) {
          
        }
        $this->breadcrumb->add('Dashboard', $this->data['admin_url'] . 'home');
        $this->breadcrumb->add('View Contact', $this->data['admin_url'] . "contact_us");
        $this->breadcrumb->add('Add Contact', '');
        $this->data['breadcrumb'] = $this->breadcrumb->output();
        $this->data['tpl_name'] = "admin/contact_us/contact_us.tpl";
        $this->smarty->assign('data', $this->data);
        $this->smarty->view('admin/admin-template.tpl');
    }

    //update client
    function update() {
        $iContectID = $this->uri->segment(4);
        $this->data['contact_detail'] = $this->contact_us_model->get_contact_details($iContectID);
        //echo "<pre>";print_r($this->data['contact_detail']);exit;
        $this->breadcrumb->add('Dashboard', $this->data['admin_url'] . 'home');
        $this->breadcrumb->add('View Contacts', $this->data['admin_url'] . "contact_us");
        $this->breadcrumb->add('Update Contact', '');
        $this->data['breadcrumb'] = $this->breadcrumb->output();
        $this->data['tpl_name'] = "admin/contact_us/contact_us.tpl";
        $this->smarty->assign('data', $this->data);
        $this->smarty->assign('eStatuses', $eStatuses);
        $this->smarty->assign('eRoles', $eRoles);
        $this->smarty->view('admin/admin_template.tpl');
    }
    //update status
    function action_update() {
        $ids = $this->input->post('iId');
        $action = $this->input->post('action');
        $tableData['tablename'] = 'contact_us';
        $tableData['update_field'] = 'iContectID';
        $count = $this->update_status($ids, $action, $tableData);
        if ($action == 'Delete') {
            $count = count($ids);
        } else {
            $count = $count;
        }
        $recordtitle = '';
        if ($count > 1) {
            $recordtitle = 'Records';
        } else {
            $recordtitle = 'Record';
        }
        if ($action == 'Delete') {
            $this->session->set_flashdata('message', "Total  ($count) " . $recordtitle . " Deleted Successfully");
        } else {
            $this->session->set_flashdata('message', "Total  ($count) " . $recordtitle . " Updated Successfully");
        }
        redirect($this->data['admin_url'] . 'contact_us');
    }
    //get client listing
    function get_contact_listing() {
        $all_user = $this->contact_us_model->get_contact();
        //echo '<pre>';print_r($all_user);exit;
        if (count($all_user) > 0) {
            /*foreach ($all_user as $key1 => $value1){
            if(strlen($value1['tMassage']>17)){
            $all_user[$key1]['tMassage']=substr($value['tMassage'],0,17)."...";
            }
            }*/
            foreach ($all_user as $key => $value) {
                $alldata[$key]['usertype'] = '<center><input type="checkbox" name="iId[]" id="iId" value="' . $value['iContectID'] . '"></center>';
                $alldata[$key]['vName'] = ucwords($value['vFirstName']) . ' ' . ucwords($value['vLastName']);
                $alldata[$key]['vEmail'] = $value['vEmail'];
                $alldata[$key]['iMobileNo'] = $value['iMobileNo'];
                $alldata[$key]['dAddedDate'] = $value['dAddedDate'];
                $alldata[$key]['tMassage'] = substr($value['tMassage'], 0, 17) . " ...";
                // $alldata[$key]['tMassage'] = $value['tMassage'];
                $alldata[$key]['editlink'] = '<center><a href="' . $this->data['base_url'] . 'contact_us/update/' . $value['iContectID'] . '"><span class="glyphicon glyphicon-list-alt">View</span></a></center>';
            }
            $aData['aaData'] = $alldata;
        } else {
            $aData['aaData'] = '';
        }
        //echo "<pre>";print_r($aData);exit;
        $json_lang = json_encode($aData);
        echo $json_lang;
        exit;
    }
    function exportcsv() {
        $record = $this->contact_us_model->getAllContactDetails();
        $RiderDeteil = array();
        for ($i = 0;$i < count($record);$i++) {
            $RiderDeteil[$i]['Customer Name'] = $record[$i]['vFirstName'] . " " . $record[$i]['vLastName'];
            $RiderDeteil[$i]['Email ID'] = $record[$i]['vEmail'];
            $RiderDeteil[$i]['Mobile No.'] = $record[$i]['iMobileNo'];
            $RiderDeteil[$i]['Massage'] = $record[$i]['tMassage'];
            $RiderDeteil[$i]['Contact Date'] = $record[$i]['dAddedDate'];
            if (!$record[$i]['dAddedDate']) {
                $RiderDeteil[$i]['RegisterDate'] = " - ";
            }
        }
        $date = date('Ymd');
        $filename = 'Contact_Detail' . $date . '.xls';
        // For excel
        header("Content-Disposition: attachment; filename=\"$filename\"");
        header("Content-Type: application/vnd.ms-excel");
        $flag = false;
        if (count($RiderDeteil) > 0) {
            foreach ($RiderDeteil as $row) {
                if (!$flag) {
                    // display field/column names as first row
                    echo implode("	", array_keys($row)) . "
";
                    $flag = true;
                }
                array_walk($row, 'cleanData');
                echo implode("	", array_values($row)) . "
";
            }
        }
        exit;
    }
}
/* End of file client.php */
/* Location: ./application/controllers/client.php */
?>