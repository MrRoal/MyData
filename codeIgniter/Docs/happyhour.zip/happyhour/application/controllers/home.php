<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Home extends Front_Controller {
	function __construct() {
		parent::__construct();
		/*$this->load->model('common_model', '', TRUE);*/
	}
	//use for display home template
	function index() {
		$this->data['ActiveClass'] = 'HomeActive';
		$imgpath = $this->data['base_upload'];
		$this->data['tpl_name'] = "home.tpl";
		
		$this->smarty->assign('data', $this->data);
		$this->smarty->assign('imgpath', $imgpath);
		$this->smarty->view('template.tpl');
	}
	function reset_password(){
		$this->data['ActiveClass'] = 'HomeActive';
		$imgpath = $this->data['base_upload'];
		$this->data['tpl_name'] = "home.tpl";
		
		$this->smarty->assign('data', $this->data);
		$this->smarty->assign('imgpath', $imgpath);
		$this->smarty->view('template.tpl');
	}
}
?>