<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
error_reporting(1);

class Webservices_keta extends CI_Controller{

    function __construct(){
        parent::__construct();
        $this->load->helper('string');
        $this->load->model('webservices_model_keta','',true);
    }

    function index(){
        $action=trim($this->input->post('action'));      
        switch($action){  
            case 'ForgotPassword':
                $this->ForgotPassword();
                break;
        }
    }

    function ForgotPassword(){
        $this->load->helper('string');
        $vEmail = trim($this->input->post('vEmail'));

        if($vEmail!=''){
            $user_info = $this->webservices_model_keta->get_user_info_by_email($vEmail);
            
            if(count($user_info)>0){
                $user_hashcode=$this->webservices_model_keta->get_user_hashcode_by_email($vEmail);
        
                // mail code //
                $name=ucfirst($user_info['vFirstName'])." ".ucfirst($user_info['vLastName']);
                $hashcode=$user_hashcode['vHashCode'];
                $reset_date=date('Y-m-d h:i:s');
                if($hashcode!=''){
                   
                    if($_SERVER["HTTP_HOST"] == '192.168.1.170'){
                        $baseurl = 'http://192.168.1.170/php/happyhour';
                    }else {
                        $baseurl = 'http://192.168.1.170/php/happyhour';  
                    }
                    $image = $baseurl.'/assets/admin/images/user.png';
                    $link="192.168.1.170/php/happyhour/home/reset_password/".$hashcode;
                    $bodyArr = array("#NAME#","#EMAIL#","#IMAGE_URL#",'#LINK#');
                    $postArr = array($name,$vEmail,$image,$link);  

                    $sendmailjourney = $this->webservices_model_keta->SendNewPasswordEmail("RESET_PASSWORD",$vEmail,$bodyArr,$postArr);
                    if($sendmailjourney>0){
                        $totalrows = $this->webservices_model_keta->update_user_resetdate_by_email($vEmail,$reset_date);
                        if($totalrows>0){
                            $data['msg'] = "Forgot password Mail Sent Successfully";
                        }
                        else{
                            $data['msg'] = "Unable to updated ";
                        }
                    }else {

                        $data['msg'] = 'Unable to sent Mail ';           
                    }
                }else {
                    $data['msg'] = 'No Hashcode Available';           
                }
                // end of mail code //
            }else {
                $data['msg'] = 'User Not Exist';
            }
        }else {
            $data['msg'] = "Plaese Enter EmailId";
        }
        header('Content-type: application/json');
        $callback = '';
        if (isset($_REQUEST['callback'])){
            $callback = filter_var($_REQUEST['callback'], FILTER_SANITIZE_STRING);
        }
        $main = json_encode($data);
        echo $callback . ''.$main.'';
        exit;       
    }
}
?>