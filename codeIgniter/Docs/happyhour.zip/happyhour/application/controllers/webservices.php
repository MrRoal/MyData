<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
error_reporting(1);

class Webservices extends CI_Controller{
    function __construct(){
        parent::__construct();

        $this->load->helper('string');
        $this->load->model('webservices_model','',true);
            
    }

    function index(){
        $action=trim($this->input->post('action'));      
        switch($action){
            case 'Login':
                $this->Login();
                break;
            case 'RegisterUser':
                $this->RegisterUser();
                break;    
        }
    }

    function Login(){

       if($this->input->post('vEmail') && $this->input->post('vPassword')){
            $vEmail = strtolower(trim($this->input->post('vEmail')));
            $vPassword = md5($this->input->post('vPassword'));
            print_r($vPassword);
            $userdata = $this->webservices_model->authenticate_user_password($vEmail,$vPassword);
            if(!empty($userdata)){
                $user_info = $this->webservices_model->authenticate_user($vEmail,$vPassword);
                if(!empty($user_info)){
                    $userprofilearr = array();
                    $userprofilearr['iUserId'] = $user_info['iUserId'];
                    $userprofilearr['vFirstName'] = $user_info['vFirstName'];
                    $userprofilearr['vLastName'] = $user_info['vLastName'];
                    $userprofilearr['vEmail'] = $user_info['vEmail'];
                    
                    $data['data'] = $userprofilearr;
                    $data['msg'] = "Success";       
                }else {
                    $data['msg'] = "Your Account is Inactive";
                }
            }else {
                $data['msg'] = "User Not Exist";       
            }
        }else {
            $data['msg'] = "Failure";
        }
        header('Content-type: application/json');
        $callback = '';
        if (isset($_REQUEST['callback'])){
            $callback = filter_var($_REQUEST['callback'], FILTER_SANITIZE_STRING);
        }
        $main = json_encode($data);
        echo $callback . ''.$main.'';
        exit;
    }

    function RegisterUser(){
    	
        $this->load->helper('string');
        if($this->input->post('type')){
            if($this->input->post('type')=='simple'){
                if($this->input->post('vFirstName') && $this->input->post('vLastName') && $this->input->post('vEmail') && $this->input->post('vPassword') && $this->input->post('eRole') && $this->input->post('eGender') && $this->input->post('iMobileNo')){
                    $vEmail = strtolower(trim($this->input->post('vEmail')));
                    $checkEmailExist = $this->webservices_model->check_mail_exist($vEmail);
                   // print_r($checkEmailExist);exit;
                    if($checkEmailExist=='no'){
                        $hash=random_string();
                        $userarr = array();
                        $userarr['vFirstName'] = $this->input->post('vFirstName');
                        $userarr['vLastName'] = $this->input->post('vLastName');
                        $userarr['vEmail'] = strtolower(trim($this->input->post('vEmail')));
                        $userarr['vPassword'] = md5($this->input->post('vPassword'));
                        $userarr['dCreatedDate'] = date('Y-m-d');
                        $userarr['eStatus'] = 'Active';
                        $userarr['vHashCode'] = $hash;
                        $userarr['iMobileNo'] = $this->input->post('iMobileNo');
                        $userarr['eRole'] = $this->input->post('eRole');
                        $userarr['eGender'] = $this->input->post('eGender');
                        $iUserId = $this->webservices_model->save_data('users',$userarr);
                    
                        if ($_FILES['vProfilePicture']['name'] !='') {
                            if(!is_dir('uploads/'))
                            {
                                @mkdir('uploads/', 0777);
                            }
                            if(!is_dir('uploads/userprofile/'))
                            {
                                @mkdir('uploads/userprofile/', 0777);
                            }
                            if(!is_dir('uploads/userprofile/'.$iUserId.'/'))
                            {
                                @mkdir('uploads/userprofile/'.$iUserId.'/', 0777);
                            }
                            $userarr['vProfilePicture'] = $_FILES['vProfilePicture']['name'];
                            $upload_dir= 'uploads/userprofile/'.$iUserId;
                            
                            $file_name=str_replace(' ','_',$_FILES['vProfilePicture']['name']);     
                            if(@copy($_FILES['vProfilePicture']['tmp_name'],$upload_dir.'/'.$file_name))
                            {
                                $this->webservices_model->update_user($file_name,$iUserId);
                            }
                        }
                       
                        if($iUserId>0){
                            $user_info = $this->webservices_model->getUserInfo($iUserId);

                            $userprofilearr = array();
                            $userprofilearr['iUserId'] = $user_info['iUserId'];
                            $userprofilearr['vFirstName'] = $user_info['vFirstName'];
                            $userprofilearr['vLastName'] = $user_info['vLastName'];
                            $userprofilearr['vEmail'] = $user_info['vEmail'];
                            $userprofilearr['vProfilePicture'] = $this->config->item('base_url').'uploads/userprofile/'.$iUserId.'/'.$user_info['vProfilePicture'];
                            $data['data'] = $userprofilearr;
                            $data['msg'] = "Success";
                        }else {
                            $data['msg'] = "Failure";       
                        }
                    }else {
                        $checkEmailExist = $this->webservices_model->check_mail_exist_with_status($this->input->post('vEmail'));
                        if($checkEmailExist=='yes'){
                            $vEmail = $this->input->post('vEmail');
                            $user_info = $this->webservices_model->get_user_info_by_email($vEmail);
                            $userprofilearr = array();
                            $userprofilearr['iUserId'] = $user_info['iUserId'];
                            $userprofilearr['vFirstName'] = $user_info['vFirstName'];
                            $userprofilearr['vLastName'] = $user_info['vLastName'];
                            $userprofilearr['vEmail'] = $user_info['vEmail'];
                            $data['data'] = $userprofilearr;
                            $data['msg'] = "User Already Exist";        
                        }else {
                            $data['msg'] = "Failure";
                        }
                    }
                }else {
                    $data['msg'] = "Failure";       
                }
            }else if($this->input->post('type')=='facebook'){

                if($this->input->post('vFirstName') && $this->input->post('vLastName') && $this->input->post('vEmail') && $this->input->post('biFBId')&& $this->input->post('eRole') && $this->input->post('eGender') && $this->input->post('iMobileNo')){
                    
                    $vEmail = strtolower(trim($this->input->post('vEmail')));
                    $checkEmailExist = $this->webservices_model->check_mail_exist($vEmail);
                    if($checkEmailExist=='no'){
                        $userarr = array();
                        $userarr['vFirstName'] = $this->input->post('vFirstName');
                        $userarr['vLastName'] = $this->input->post('vLastName');
                        $userarr['vEmail'] = strtolower(trim($this->input->post('vEmail')));
                        $userarr['dCreatedDate'] = date('Y-m-d');
                        $userarr['eStatus'] = 'Active';
                        $userarr['biFBId'] = $this->input->post('biFBId');
                        $generated_string = random_string('alnum', 6);
                        $userarr['vPassword'] = md5($generated_string);
                        $userarr['iMobileNo'] = $this->input->post('iMobileNo');
                        $userarr['eRole'] = $this->input->post('eRole');
                        $userarr['eGender'] = $this->input->post('eGender');

                         /*if ($this->input->post('vProfilePicture') !='') {
                            if(!is_dir('uploads/'))
                            {
                                @mkdir('uploads/', 0777);
                            }
                            if(!is_dir('uploads/userprofile/'))
                            {
                                @mkdir('uploads/userprofile/', 0777);
                            }
                            if(!is_dir('uploads/userprofile/'.45.'/'))
                            {
                                @mkdir('uploads/userprofile/'.45.'/', 0777);
                            }
           
                            $upload_dir= 'uploads/userprofile/'.45;
                            $content = file_get_contents('http://www.gettyimages.in/gi-resources/images/Homepage/Hero/UK/CMS_Creative_164657191_Kingfisher.jpg');
	                        print_r($content);
	                        file_put_contents($upload_dir.'/image.jpg', $content);

                            $file_name=str_replace(' ','_',$_FILES['vProfilePicture']['name']);     
                            if(@copy($_FILES['vProfilePicture']['tmp_name'],$upload_dir.'/'.$file_name))
                            {
                                $this->webservices_model->update_user($file_name,$iUserId);
                            }
                        }*/
                       
                        $iUserId = $this->webservices_model->save_data('users',$userarr);

                        if($iUserId>0){
                            // mail code //
                            $user_info = $this->webservices_model->getUserInfo($iUserId);
                            $userprofilearr = array();
                            $userprofilearr['iUserId'] = $user_info['iUserId'];
                            $userprofilearr['vFirstName'] = $user_info['vFirstName'];
                            $userprofilearr['vLastName'] = $user_info['vLastName'];
                            $userprofilearr['vEmail'] = $user_info['vEmail'];
                            $data['data'] = $userprofilearr;
                            $data['msg'] = "Success";
                            // end of mail code //
                        }else {
                            $data['msg'] = "Failure";       
                        }
                    }else {
                        $checkEmailExist = $this->webservices_model->check_mail_exist_with_status($this->input->post('email'));
                        if($checkEmailExist=='yes'){
                            $vEmail = $this->input->post('vEmail');
                            $user_info = $this->webservices_model->get_user_info_by_email($vEmail);
                            $userprofilearr = array();
                            $userprofilearr['iUserId'] = $user_info['iUserId'];
                            $userprofilearr['vFirstName'] = $user_info['vFirstName'];
                            $userprofilearr['vLastName'] = $user_info['vLastName'];
                            $userprofilearr['vEmail'] = $user_info['vEmail'];
                            $data['data'] = $userprofilearr;
                            $data['msg'] = "User Already Exist";            
                        }else {
                            $data['msg'] = "Failure";   
                        }
                    }
                }else {
                    $data['msg'] = "Failure";       
                }
            }
        }else {
            $data['msg'] = "Failure";
        }
        header('Content-type: application/json');
        $callback = '';
        if (isset($_REQUEST['callback'])){
            $callback = filter_var($_REQUEST['callback'], FILTER_SANITIZE_STRING);
        }
        $main = json_encode($data);
        echo $callback . ''.$main.'';
        exit;

    }


}
?>