<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Admin_management_model extends CI_Model {
    function __construct() {
        parent::__construct();
    }

    function getalladmin($type){
        $this->db->select('iAdminId,vFirstName,vLastName,vEmail,eRole,eStatus');
        $this->db->select("DATE_FORMAT(dCreatedDate,'%M %D, %Y %h:%i %p') AS dCreatedDate",FALSE);
        $this->db->from('admin');
        /*$this->db->where('eRole',$type);*/
        $this->db->order_by('iAdminId','desc');
        $query = $this->db->get();
        return $query->result_array();  
    }

    function get_admin_details($iAdminId) {
        $this->db->select('iAdminId,vFirstName,vLastName,vEmail,iMobileNo,dCreatedDate,eRole,eStatus');
        $this->db->from('admin');
        $this->db->where('iAdminId', $iAdminId);
        $query = $this->db->get();
        return $query->row_array();
    }
    function edit_admin($data) {
        $this->db->update("admin", $data, array('iAdminId' => $data['iAdminId']));
        return $this->db->affected_rows();
    }
    function add_admin($data) {
        $this->db->insert('admin', $data);
        return $this->db->insert_id();
    }
    function get_all_admins($iAdminId) {
        $this->db->select(' ');
        $this->db->from('admin');
        $this->db->where('iAdminId !=', $iAdminId);
        $this->db->order_by('iAdminId desc');
        $query = $this->db->get();
        return $query->result_array();
    }
    function admin_exists($vEmail) {
        $this->db->select('');
        $this->db->from('admin');
        $this->db->where('vEmail', $vEmail);
        $query = $this->db->get();
        return $query->num_rows();
    }
}
?>