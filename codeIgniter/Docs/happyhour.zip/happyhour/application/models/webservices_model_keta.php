<?php if( !defined('BASEPATH')) exit('No direct script allowed to access');

class webservices_model_keta extends CI_Model
{
    function __construct()
    {
        parent::__construct();
    }

    function get_user_info_by_email($vEmail){
        $this->db->select('iUserId,vEmail,vFirstName,vLastName');
        $this->db->from('users');
        $this->db->where('vEmail',$vEmail);
        $que = $this->db->get();
        return $que->row_array();
    }

    function get_user_hashcode_by_email($vEmail){
        $this->db->select('vHashCode');
        $this->db->from('users');
        $this->db->where('vEmail',$vEmail);
        $que = $this->db->get();
        return $que->row_array();
    }
    function update_user_resetdate_by_email($email,$reset_date){
        $passwordarr['dRestPassword'] = $reset_date;
        $this->db->where('vEmail',$email);
        $this->db->update('users',$passwordarr);
        return $this->db->affected_rows();
    }

    function SendNewPasswordEmail($EmailCode,$emailid,$bodyArr,$postArr){
        $email_info = $this->list_sysemaildata($EmailCode)->result(); 
        $Subject = strtr($email_info[0]->vEmailSubject, "\r\n" , "  " );
        $body =stripslashes($email_info[0]->tEmailMessage);
        $vFromName = $email_info[0]->vFromName;
        $body = str_replace($bodyArr,$postArr, $body);
        require_once 'PHPMailer-master/PHPMailerAutoload.php';
        $mail = new PHPMailer;
        $mail->isSMTP();
        $mail->Host = "smtp.gmail.com";
        $mail->SMTPAuth = true;       
        $mail->SMTPDebug = 0;                               // Enable SMTP authentication
        $mail->Username = 'demo1.testing1@gmail.com';       // SMTP username
        $mail->Password = 'demo1234'; 
        $mail->SMTPSecure = 'tls'; 
        $mail->Port = 587;                                  // TCP port to connect to
        $mail->From = 'demo1.testing1@gmail.com';
        $mail->FromName = 'Happy hour';
        $mail->addAddress($emailid);                          // Add a recipient
        
        $mail->WordWrap = 50;                                 // Set word wrap to 50 characters
        $mail->isHTML(true);                                  // Set email format to HTML
        $mail->Subject = $Subject;
        $mail->Body    = $body;
        $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';
        if(!$mail->send()) {
            $res = 0;
        } else {
            $res = 1;
        }
        return $res;    
    }
    function list_sysemaildata($EmailCode) {
        $this->db->select('');
        $this->db->from('emailtemplate');
        $this->db->where('vEmailCode', $EmailCode);
        return $this->db->get();
    }
}

?>