<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class webservices_model extends CI_Model {
    function __construct() {
        parent::__construct();
    }

    function authenticate_user_password($vEmail,$vPassword){
        $this->db->select('iUserId,vEmail,vFirstName,vLastName');
        $this->db->from('users');
        $this->db->where('vEmail',$vEmail);
        $this->db->where('vPassword',$vPassword);
        $que = $this->db->get();
        return $que->row_array();    
    }

    function authenticate_user($vEmail,$vPassword){
        $this->db->select('iUserId,vEmail,vFirstName,vLastName');
        $this->db->from('users');
        $this->db->where('vEmail',$vEmail);
        $this->db->where('vPassword',$vPassword);
        $this->db->where('eStatus','Active');
        $que = $this->db->get();
        return $que->row_array();       
    }

    function check_mail_exist($vEmail){
        $this->db->select('');
        $this->db->from('users');
        $this->db->where('vEmail',$vEmail);
        $que = $this->db->get();
        $res = $que->num_rows();

        $this->db->select('');
        $this->db->from('admin');
        $this->db->where('vEmail',$vEmail);
        $que1 = $this->db->get();
        $res1 = $que1->num_rows();


        if($res>0 || $res1>0){
            return 'yes';
        }
        else {
            return 'no';
        }
    }

    function save_data($table,$data){
        $this->db->insert($table,$data);
        return $this->db->insert_id();
    }
    function getUserInfo($iUserId){
        $this->db->select('iUserId,vFirstName,vLastName,vEmail,vProfilePicture');
        $this->db->from('users');
        $this->db->where('iUserId',$iUserId);
        $que = $this->db->get();
        return $que->row_array();
    }

    function get_user_info_by_email($vEmail){
        $this->db->select('iUserId,vEmail,vFirstName,vLastName');
        $this->db->from('users');
        $this->db->where('vEmail',$vEmail);
        $que = $this->db->get();
        return $que->row_array();
    }

    function check_mail_exist_with_status($vEmail){
        $this->db->select('');
        $this->db->from('users');
        $this->db->where('vEmail',$vEmail);
        $this->db->where('eStatus','Active');
        $que = $this->db->get();
        $res = $que->num_rows();
        if($res>0){
            return 'yes';
        }
        else {
            return 'no';
        }
    }

    function getEmailInfo($EmailCode){
        $this->db->select('');
        $this->db->from('emailtemplate');
        $this->db->where('vEmailCode',$EmailCode);
        $que = $this->db->get();
        return $que->row_array();
    }

    function update_user($file_name,$iUserId){
        $save_Data['vProfilePicture']=$file_name;
        $this->db->where('iUserId',$iUserId);
        $this->db->update('users',$save_Data);
    }

}
?>

