<?php /* Smarty version Smarty-3.1.11, created on 2015-11-02 19:59:31
         compiled from "application/views/templates/admin/admin-template.tpl" */ ?>
<?php /*%%SmartyHeaderCode:123175394556375e3338c1d1-52497130%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'c75e7c2278c215eb39476169a0fd51b1c8711a6a' => 
    array (
      0 => 'application/views/templates/admin/admin-template.tpl',
      1 => 1446455709,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '123175394556375e3338c1d1-52497130',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'data' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.11',
  'unifunc' => 'content_56375e333bc2b1_25010972',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56375e333bc2b1_25010972')) {function content_56375e333bc2b1_25010972($_smarty_tpl) {?><!DOCTYPE html>
<html>
<head>
    <title> ::: <?php echo $_smarty_tpl->tpl_vars['data']->value['SITE_NAME'];?>
 ::: </title>
    <!-- Bootstrap -->
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />

    <link rel="shortcut icon" type="image/x-icon" href="<?php echo $_smarty_tpl->tpl_vars['data']->value['admin_base_url'];?>
assets/admin/image/favicon.ico">
    <?php echo $_smarty_tpl->getSubTemplate ('admin/common_css.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

    <link href="<?php echo $_smarty_tpl->tpl_vars['data']->value['admin_css_path'];?>
dataTables.bootstrap.css" rel="stylesheet" media="screen">
    <script src="<?php echo $_smarty_tpl->tpl_vars['data']->value['admin_js_path'];?>
plugins/jquery/jquery-1.10.2.min.js" type="text/javascript"></script>
    <script src="<?php echo $_smarty_tpl->tpl_vars['data']->value['admin_js_path'];?>
plugins/jquery-ui/jquery-ui-1.10.4.min.js" type="text/javascript"></script>
    <!-- Bootstrap -->
    <script src="<?php echo $_smarty_tpl->tpl_vars['data']->value['admin_js_path'];?>
plugins/bootstrap/bootstrap.min.js" type="text/javascript"></script>
    <script src="<?php echo $_smarty_tpl->tpl_vars['data']->value['admin_js_path'];?>
plugins/datatables/jquery.dataTables.js" type="text/javascript"></script>
    <script src="<?php echo $_smarty_tpl->tpl_vars['data']->value['admin_js_path'];?>
plugins/datatables/dataTables.bootstrap.js" type="text/javascript"></script>

   
    <script src="<?php echo $_smarty_tpl->tpl_vars['data']->value['admin_js_path'];?>
plugins/bootstrap/bootstrap.min.js" type="text/javascript"></script>
    <script src="<?php echo $_smarty_tpl->tpl_vars['data']->value['admin_js_path'];?>
plugins/datepicker/datepicker.js" type="text/javascript"></script>
    <script src="<?php echo $_smarty_tpl->tpl_vars['data']->value['admin_js_path'];?>
fileinput.js" type="text/javascript"></script>
    <script src="<?php echo $_smarty_tpl->tpl_vars['data']->value['admin_js_path'];?>
common.js"></script>
    <script type="text/javascript">
        var base_image = '<?php echo $_smarty_tpl->tpl_vars['data']->value['admin_image_path'];?>
';
        var base_url = '<?php echo $_smarty_tpl->tpl_vars['data']->value['admin_url'];?>
';
    </script>       
</head>

<body class="fixed">
    <?php echo $_smarty_tpl->getSubTemplate ("admin/header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>


    <div class="wrapper">
        <?php echo $_smarty_tpl->getSubTemplate ("admin/left_sidemenu.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>


        <?php echo $_smarty_tpl->getSubTemplate ($_smarty_tpl->tpl_vars['data']->value['tpl_name'], $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

    </div>

    <?php echo $_smarty_tpl->getSubTemplate ('admin/common_js.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

    <footer>
        <?php echo $_smarty_tpl->getSubTemplate ("admin/footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>
                    
    </footer>
    <script src="<?php echo $_smarty_tpl->tpl_vars['data']->value['admin_js_path'];?>
bootstrap.min.js"></script>
    <!-- bootstrap progress js -->
    <script src="<?php echo $_smarty_tpl->tpl_vars['data']->value['admin_js_path'];?>
progressbar/bootstrap-progressbar.min.js"></script>
    <script src="<?php echo $_smarty_tpl->tpl_vars['data']->value['admin_js_path'];?>
nicescroll/jquery.nicescroll.min.js"></script>
    <!-- daterangepicker -->
    <script src="<?php echo $_smarty_tpl->tpl_vars['data']->value['admin_js_path'];?>
custom.js"></script>

</body>
</html><?php }} ?>