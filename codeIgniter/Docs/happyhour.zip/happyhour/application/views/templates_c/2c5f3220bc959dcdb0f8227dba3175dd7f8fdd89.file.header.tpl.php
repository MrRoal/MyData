<?php /* Smarty version Smarty-3.1.11, created on 2015-11-02 19:59:31
         compiled from "application/views/templates/admin/header.tpl" */ ?>
<?php /*%%SmartyHeaderCode:64004720356375e333c8ef5-27190001%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '2c5f3220bc959dcdb0f8227dba3175dd7f8fdd89' => 
    array (
      0 => 'application/views/templates/admin/header.tpl',
      1 => 1446276697,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '64004720356375e333c8ef5-27190001',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'data' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.11',
  'unifunc' => 'content_56375e333d69d4_27744671',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56375e333d69d4_27744671')) {function content_56375e333d69d4_27744671($_smarty_tpl) {?><header>
    <nav class="navbar navbar-static-top">
        <div class="navbar">
            <a href="<?php if ($_smarty_tpl->tpl_vars['data']->value['mimusica_login_info']['eRole']=='Brand'){?><?php echo $_smarty_tpl->tpl_vars['data']->value['base_url'];?>
brands/brdashboard<?php }else{ ?><?php echo $_smarty_tpl->tpl_vars['data']->value['base_url'];?>
home<?php }?>" class="in-logo innerlogopart"> <img src='<?php echo $_smarty_tpl->tpl_vars['data']->value['base_image'];?>
inner-logo-admin.png' class='headerlogoimgsize' alt="Happy Hour"></img></a>
        </div>
        <div class="navbar-right">
            <ul class="nav navbar-nav">
                <li class="dropdown widget-user">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                    <span><?php echo $_smarty_tpl->tpl_vars['data']->value['admindetail']['vFirstName'];?>
 <?php echo $_smarty_tpl->tpl_vars['data']->value['admindetail']['vLastName'];?>
 <i class="fa fa-caret-down"></i></span>
                    </a>
                    <ul class="dropdown-menu">
                        <li class="footer">
                            <a href="<?php echo $_smarty_tpl->tpl_vars['data']->value['admin_url'];?>
authentication/logout"><i class="fa fa-power-off"></i>Log Out</a>
                        </li>
                    </ul>
                </li>
            </ul>
        </div>
    </nav>
</header><?php }} ?>