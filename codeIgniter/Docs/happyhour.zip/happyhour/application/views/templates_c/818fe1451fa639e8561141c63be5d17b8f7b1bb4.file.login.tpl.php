<?php /* Smarty version Smarty-3.1.11, created on 2015-11-02 20:13:04
         compiled from "application/views/templates/admin/login.tpl" */ ?>
<?php /*%%SmartyHeaderCode:108535811156376160e0c9e6-81459489%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '818fe1451fa639e8561141c63be5d17b8f7b1bb4' => 
    array (
      0 => 'application/views/templates/admin/login.tpl',
      1 => 1446275143,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '108535811156376160e0c9e6-81459489',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'data' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.11',
  'unifunc' => 'content_56376160e27152_56029310',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56376160e27152_56029310')) {function content_56376160e27152_56029310($_smarty_tpl) {?><!DOCTYPE html>
<html class="no-js">
    <head>
        <title> ::: <?php echo $_smarty_tpl->tpl_vars['data']->value['SITE_NAME'];?>
 ::: </title>
        <link rel="shortcut icon" type="image/x-icon" href="<?php echo $_smarty_tpl->tpl_vars['data']->value['admin_base_url'];?>
assets/admin/image/favicon.ico">
        <!-- Bootstrap -->
        <?php echo $_smarty_tpl->getSubTemplate ('admin/common_css.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

        
    </head>
    <body class="login fixed">

        <div class="wrapper animated flipInY">
            <div class="logo"><img src='<?php echo $_smarty_tpl->tpl_vars['data']->value['base_image'];?>
new_logo.png' alt="Happy Hour"></div>
            <div class="box">
                <div class="header clearfix">
                    <div class="pull-left"><i class="fa fa-sign-in"></i> Log In</div>
                    <div class="pull-right"><a href="<?php echo $_smarty_tpl->tpl_vars['data']->value['admin_url'];?>
authentication/forgotpassword"><i class="fa fa-times"></i></a></div>
                </div>
                <form id="loginform" method="post" action="<?php echo $_smarty_tpl->tpl_vars['data']->value['admin_url'];?>
authentication">
                    <?php if ($_smarty_tpl->tpl_vars['data']->value['message']!=''){?>
                        <div class="alert alert-warning no-radius no-margin padding-sm"><i class="fa fa-info-circle"></i> <?php echo $_smarty_tpl->tpl_vars['data']->value['message'];?>
</div>
                    <?php }?>
                    <div class="box-body padding-md">
                        <div class="form-group">
                            <input type="text" name="vEmail" id="vEmail" class="form-control loginpage" placeholder="Email ID" onkeydown="Javascript: if (event.keyCode==13) check_user_email();"/>
                            <span id="valemail" style="display:none;" class="validationfrm">Please Enter Email ID.</span>
                        </div>
                        <div class="form-group">
                            <input type="password" name="vPassword" id="vPassword" class="form-control loginpage" placeholder="Password" onkeydown="Javascript: if (event.keyCode==13) check_user_email();"/>
                            <span id="valpwd" style="display:none;" class="validationfrm">Please Enter Password.</span>
                        </div>
                        
                        <div class="box-footer">                                                               
                            <button type="submit" class="btn btn-success btn-block">Sign In</button>
                            <br>
                            <a href='<?php echo $_smarty_tpl->tpl_vars['data']->value['admin_url'];?>
authentication/forgotpassword'>
                            <button type="button" class="btn btn-success btn-block forgbtn">Forgot Password?</button></a>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </body>
</html><?php }} ?>