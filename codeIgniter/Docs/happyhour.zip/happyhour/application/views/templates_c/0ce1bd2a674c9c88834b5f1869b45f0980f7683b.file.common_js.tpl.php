<?php /* Smarty version Smarty-3.1.11, created on 2015-11-02 19:59:31
         compiled from "application/views/templates/admin/common_js.tpl" */ ?>
<?php /*%%SmartyHeaderCode:183891874156375e334701f8-90468434%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '0ce1bd2a674c9c88834b5f1869b45f0980f7683b' => 
    array (
      0 => 'application/views/templates/admin/common_js.tpl',
      1 => 1446447472,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '183891874156375e334701f8-90468434',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'data' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.11',
  'unifunc' => 'content_56375e33482134_42920417',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56375e33482134_42920417')) {function content_56375e33482134_42920417($_smarty_tpl) {?><!-- Javascript -->
<!-- Bootstrap -->
<!-- Interface -->
<script src="<?php echo $_smarty_tpl->tpl_vars['data']->value['admin_js_path'];?>
plugins/jquery-countTo/jquery.countTo.js" type="text/javascript"></script>
<script src="<?php echo $_smarty_tpl->tpl_vars['data']->value['admin_js_path'];?>
plugins/slimScroll/jquery.slimscroll.min.js" type="text/javascript"></script>
<script src="<?php echo $_smarty_tpl->tpl_vars['data']->value['admin_js_path'];?>
plugins/pace/pace.min.js" type="text/javascript"></script>
<!-- Forms -->
<script src="<?php echo $_smarty_tpl->tpl_vars['data']->value['admin_js_path'];?>
custom.js" type="text/javascript"></script>
<script src="<?php echo $_smarty_tpl->tpl_vars['data']->value['admin_js_path'];?>
plugins/bootstrapValidator/bootstrapValidator.min.js" type="text/javascript"></script>
<script src="<?php echo $_smarty_tpl->tpl_vars['data']->value['admin_js_path'];?>
commonvalidation.js" type="text/javascript"></script><?php }} ?>