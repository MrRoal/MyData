<?php /* Smarty version Smarty-3.1.11, created on 2015-11-02 19:59:31
         compiled from "application/views/templates/admin/footer.tpl" */ ?>
<?php /*%%SmartyHeaderCode:105477167556375e334848f4-10746819%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '6ae61687e8913f47cefd1c96d56c84e7c4ce2a67' => 
    array (
      0 => 'application/views/templates/admin/footer.tpl',
      1 => 1446038634,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '105477167556375e334848f4-10746819',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.11',
  'unifunc' => 'content_56375e33485a01_75715299',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56375e33485a01_75715299')) {function content_56375e33485a01_75715299($_smarty_tpl) {?><div class="">
    <p class="pull-right">
        <span class="lead"> <i class="fa fa-paw"></i> Happy Hour</span>
    </p>
</div>
<div class="clearfix"></div><?php }} ?>