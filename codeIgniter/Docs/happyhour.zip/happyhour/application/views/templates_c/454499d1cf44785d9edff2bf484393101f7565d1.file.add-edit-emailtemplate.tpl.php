<?php /* Smarty version Smarty-3.1.11, created on 2015-11-02 20:13:27
         compiled from "application/views/templates/admin/emailtemplate/add-edit-emailtemplate.tpl" */ ?>
<?php /*%%SmartyHeaderCode:15344243755637617711eb47-49619626%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '454499d1cf44785d9edff2bf484393101f7565d1' => 
    array (
      0 => 'application/views/templates/admin/emailtemplate/add-edit-emailtemplate.tpl',
      1 => 1446450004,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '15344243755637617711eb47-49619626',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'data' => 0,
    'eSendTypes' => 0,
    'eStatuses' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.11',
  'unifunc' => 'content_5637617715f654_21917382',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5637617715f654_21917382')) {function content_5637617715f654_21917382($_smarty_tpl) {?><div class="rightside">
	<div class="page-head breadpad">
		<!-- <h1>User</h1> -->
		<ol class="breadcrumb">
			<li>You are here:</li>
			<li><a href="<?php echo $_smarty_tpl->tpl_vars['data']->value['admin_url'];?>
home">Dashboard</a></li>
			<li><a href="<?php echo $_smarty_tpl->tpl_vars['data']->value['admin_url'];?>
emailtemplate">View Email Template</a></li>
			<li class="active"><?php if ($_smarty_tpl->tpl_vars['data']->value['action']=='update'){?>Update<?php }else{ ?>Add<?php }?> Email Template</li>
		</ol>
	</div>
	<div class="content">
	<!-- Main row -->
		<div class="row">
			<div class="col-md-12">
				<div class="box">
					<div class="box-title">
						<h3><?php if ($_smarty_tpl->tpl_vars['data']->value['action']=='update'){?>Update<?php }else{ ?>Add<?php }?> User</h3>
					</div>

				<h2></h2>
				<div class="clearfix"></div>
			</div>
			<div class="x_content">
				<form class="form-horizontal form-label-left" id="frmemailtemplate" action="<?php echo $_smarty_tpl->tpl_vars['data']->value['admin_url'];?>
emailtemplate/<?php echo $_smarty_tpl->tpl_vars['data']->value['action'];?>
" method="post" enctype="multipart/form-data">
						<input type="hidden" name="iEmailTemplateId" value="<?php echo $_smarty_tpl->tpl_vars['data']->value['all_emailtemplate']['iEmailTemplateId'];?>
">

						<div class="form-group">
							<label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name">Email ID Title<sup><span style="color:#CC2131">*</span></sup></label>
							<div class="col-md-6 col-sm-6 col-xs-12">
								<input type="text" class="form-control col-md-7 col-xs-12" id="vEmailTitle" name="vEmailTitle" value="<?php echo $_smarty_tpl->tpl_vars['data']->value['all_emailtemplate']['vEmailTitle'];?>
">
							</div>
						</div>

						<div class="form-group">
							<label class="control-label col-md-3 col-sm-3 col-xs-12" for="typeahead">Email ID Code<sup><span style="color:#CC2131">*</span></sup></label>
							<div class="col-md-6 col-sm-6 col-xs-12">
								<input type="text" class="form-control col-md-7 col-xs-12" id="vEmailCode" name="vEmailCode" value="<?php echo $_smarty_tpl->tpl_vars['data']->value['all_emailtemplate']['vEmailCode'];?>
">
							</div>
						</div>

						<div class="form-group">
							<label class="control-label col-md-3 col-sm-3 col-xs-12" for="typeahead">From Name<sup><span style="color:#CC2131">*</span></sup></label>
							<div class="col-md-6 col-sm-6 col-xs-12">
								<input type="text" class="form-control col-md-7 col-xs-12" id="vFromName" name="vFromName" value="<?php echo $_smarty_tpl->tpl_vars['data']->value['all_emailtemplate']['vFromName'];?>
">
							</div>
						</div>

				
						<div class="form-group">
							<label class="control-label col-md-3 col-sm-3 col-xs-12" for="typeahead">From Email ID<sup><span style="color:#CC2131">*</span></sup></label>
							<div class="col-md-6 col-sm-6 col-xs-12">
								<input type="text" class="form-control col-md-7 col-xs-12" id="vFromEmail" name="vFromEmail" value="<?php echo $_smarty_tpl->tpl_vars['data']->value['all_emailtemplate']['vFromEmail'];?>
">
							</div>
						</div>
						

						<div class="form-group">
							<label class="control-label col-md-3 col-sm-3 col-xs-12" for="typeahead">Email ID Subject<sup><span style="color:#CC2131">*</span></sup> </label>
							<div class="col-md-6 col-sm-6 col-xs-12">
								<input type="text" class="form-control col-md-7 col-xs-12" id="vEmailSubject" name="vEmailSubject" value="<?php echo $_smarty_tpl->tpl_vars['data']->value['all_emailtemplate']['vEmailSubject'];?>
">
							</div>
						</div>

						<div class="form-group">
							<label class="control-label col-md-3 col-sm-3 col-xs-12" for="typeahead">Email ID Message</label>
							<div class="col-md-6 col-sm-6 col-xs-12">
								<textarea id="tEmailMessage" name="tEmailMessage" cols="10" rows="10"><?php echo $_smarty_tpl->tpl_vars['data']->value['all_emailtemplate']['tEmailMessage'];?>
</textarea>
							</div>
						</div>


						<div class="form-group">
							<label class="control-label col-md-3 col-sm-3 col-xs-12" for="typeahead">Email ID Footer<sup><span style="color:#CC2131">*</span></sup> </label>
							<div class="col-md-6 col-sm-6 col-xs-12">
								<input type="text" class="form-control col-md-7 col-xs-12" id="vEmailFooter" name="vEmailFooter" value="<?php echo $_smarty_tpl->tpl_vars['data']->value['all_emailtemplate']['vEmailFooter'];?>
">
							</div>
						</div>
						
						<div class="form-group">
							<label class="control-label col-md-3 col-sm-3 col-xs-12" for="typeahead">Send Type<sup><span style="color:#CC2131">*</span></sup> </label>
							<div class="col-md-6 col-sm-6 col-xs-12">
								<select class="form-control col-md-7 col-xs-12" name="eSendType" id="eSendType">
									<option value="" >-- Select Send Type--</option>
									<?php if (isset($_smarty_tpl->tpl_vars['smarty']->value['section']['i'])) unset($_smarty_tpl->tpl_vars['smarty']->value['section']['i']);
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['name'] = 'i';
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['loop'] = is_array($_loop=$_smarty_tpl->tpl_vars['eSendTypes']->value) ? count($_loop) : max(0, (int)$_loop); unset($_loop);
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['show'] = true;
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['max'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['loop'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['step'] = 1;
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['start'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['step'] > 0 ? 0 : $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['loop']-1;
if ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['show']) {
    $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['total'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['loop'];
    if ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['total'] == 0)
        $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['show'] = false;
} else
    $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['total'] = 0;
if ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['show']):

            for ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['index'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['start'], $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['iteration'] = 1;
                 $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['iteration'] <= $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['total'];
                 $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['index'] += $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['step'], $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['iteration']++):
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['rownum'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['iteration'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['index_prev'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['index'] - $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['step'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['index_next'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['index'] + $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['step'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['first']      = ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['iteration'] == 1);
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['last']       = ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['iteration'] == $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['total']);
?>
									<option value="<?php echo $_smarty_tpl->tpl_vars['eSendTypes']->value[$_smarty_tpl->getVariable('smarty')->value['section']['i']['index']];?>
" <?php if ($_smarty_tpl->tpl_vars['eSendTypes']->value[$_smarty_tpl->getVariable('smarty')->value['section']['i']['index']]==$_smarty_tpl->tpl_vars['data']->value['all_emailtemplate']['eSendType']){?> selected <?php }?> ><?php echo $_smarty_tpl->tpl_vars['eSendTypes']->value[$_smarty_tpl->getVariable('smarty')->value['section']['i']['index']];?>
</option>
									<?php endfor; endif; ?>
								</select>
							</div>
						</div>
						
						<?php if ($_smarty_tpl->tpl_vars['data']->value['action']=='update'){?>
						<div class="form-group">
							<label class="control-label col-md-3 col-sm-3 col-xs-12" for="typeahead">Status<sup><span style="color:#CC2131">*</span></sup></label>
							<div class="col-md-6 col-sm-6 col-xs-12">
								<select class="form-control col-md-7 col-xs-12" name="eStatus" id="eStatus" >
									<option value="">-- Select Status --</option>
									<?php if (isset($_smarty_tpl->tpl_vars['smarty']->value['section']['i'])) unset($_smarty_tpl->tpl_vars['smarty']->value['section']['i']);
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['name'] = 'i';
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['loop'] = is_array($_loop=$_smarty_tpl->tpl_vars['eStatuses']->value) ? count($_loop) : max(0, (int)$_loop); unset($_loop);
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['show'] = true;
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['max'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['loop'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['step'] = 1;
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['start'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['step'] > 0 ? 0 : $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['loop']-1;
if ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['show']) {
    $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['total'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['loop'];
    if ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['total'] == 0)
        $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['show'] = false;
} else
    $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['total'] = 0;
if ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['show']):

            for ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['index'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['start'], $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['iteration'] = 1;
                 $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['iteration'] <= $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['total'];
                 $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['index'] += $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['step'], $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['iteration']++):
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['rownum'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['iteration'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['index_prev'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['index'] - $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['step'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['index_next'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['index'] + $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['step'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['first']      = ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['iteration'] == 1);
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['last']       = ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['iteration'] == $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['total']);
?>
									<option <?php if ($_smarty_tpl->tpl_vars['eStatuses']->value[$_smarty_tpl->getVariable('smarty')->value['section']['i']['index']]==$_smarty_tpl->tpl_vars['data']->value['all_emailtemplate']['eStatus']){?>selected="selected"<?php }?>value="<?php echo $_smarty_tpl->tpl_vars['eStatuses']->value[$_smarty_tpl->getVariable('smarty')->value['section']['i']['index']];?>
"><?php echo $_smarty_tpl->tpl_vars['eStatuses']->value[$_smarty_tpl->getVariable('smarty')->value['section']['i']['index']];?>
</option>
									<?php endfor; endif; ?>
								</select>
							</div>
						</div>
						<?php }?>
						<div class="ln_solid"></div>
						<div class="form-group">
							<div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
								<?php if ($_smarty_tpl->tpl_vars['data']->value['action']=='create'){?>
								<button type="submit" id="btn-save" class="btn btn-success" onclick="validate();">Save</button>
								<?php }else{ ?>
									<button type="submit" id="btn-save" class="btn btn-success" onclick="validate();">Save Change</button>
								<?php }?>
								<button type="button" class="btn btn-primary" onclick="returnme();">Cancel</button>
								<span  id="loader" style="float: left;padding-right:15px;display: block;"></span>
							</div>
						</div>
					</fieldset>
				</form>
			</div>
		</div>
	</div>
</div>

<script type="text/javascript">

	$(document).ready(function () {
		$('#frmemailtemplate').bootstrapValidator({
		message: 'This value is not valid',
		icon: {
			valid: 'glyphicon glyphicon-ok',
			invalid: 'glyphicon glyphicon-remove',
			validating: 'glyphicon glyphicon-refresh'
		},
		fields: {
			vEmailTitle: {
				validators: {
					notEmpty: { message: 'Email Title is required and can\'t be empty' },
					 
				}
			},
			vEmailCode: {
				validators: {
					notEmpty: { message: 'Email Code is required and can\'t be empty' },
					 
				}
			},
			vFromEmail: {
				validators: {
					notEmpty: {
						message: 'Email address is required and can\'t be empty'
					},
					emailAddress: {
						message: 'The input is not a valid email address'
					}
				}
			},
			vFromName: {
				validators: {
					notEmpty: {
						message: 'From is required and can\'t be empty'
					},
					 
				}  
			},
			vEmailFooter: {
				validators: {
					notEmpty: {
						message: 'Email Footer is required and can\'t be empty'
					},
					 
				}  
			},
			vEmailSubject: {
				validators: {
					notEmpty: {
						message: 'Email Subject is required and can\'t be empty'
					},
					 
				}  
			},
			eSendType: {
				validators: {
					notEmpty: {
						message: 'Send Type is required and can\'t be empty'
					},
					 
				}  
			},
			eStatus: {
				validators: {
					notEmpty: {
						message: 'Status is required and can\'t be empty'
					}
				}
			}
		}
	});
});
	function returnme()
	{
		window.location.href = base_url+'emailtemplate';
	}
	tinymce.init({
		selector: "#tEmailMessage",
		height: "250",
		plugins: [ "advlist autolink lists link image charmap print preview hr anchor pagebreak",
			"searchreplace wordcount visualblocks visualchars code fullscreen",
			"insertdatetime media nonbreaking save table contextmenu directionality",
			"emoticons template paste textcolor"
		],
		toolbar1: "insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | print  media | forecolor backcolor | link | preview | code",
		toolbar2: " ",
		image_advtab: true,
		templates: [{title: 'Test template 1', content: 'Test 1'},{title: 'Test template 2', content: 'Test 2'}]
	});
</script>
<?php }} ?>