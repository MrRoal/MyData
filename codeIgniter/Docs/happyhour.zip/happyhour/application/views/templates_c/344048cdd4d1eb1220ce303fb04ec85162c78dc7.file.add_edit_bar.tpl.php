<?php /* Smarty version Smarty-3.1.11, created on 2015-11-02 20:22:48
         compiled from "application/views/templates/admin/bar/add_edit_bar.tpl" */ ?>
<?php /*%%SmartyHeaderCode:9082558355637606f42a2e7-98995558%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '344048cdd4d1eb1220ce303fb04ec85162c78dc7' => 
    array (
      0 => 'application/views/templates/admin/bar/add_edit_bar.tpl',
      1 => 1446470558,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '9082558355637606f42a2e7-98995558',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.11',
  'unifunc' => 'content_5637606f4d3294_34550994',
  'variables' => 
  array (
    'data' => 0,
    'barOweners' => 0,
    'eFeatured' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5637606f4d3294_34550994')) {function content_5637606f4d3294_34550994($_smarty_tpl) {?><div class="rightside">
    <div class="page-head breadpad">
        <ol class="breadcrumb">
            <li>You are here:</li>
            <li><a href="<?php echo $_smarty_tpl->tpl_vars['data']->value['base_url'];?>
home">Dashboard</a></li>
            <li><a href="<?php echo $_smarty_tpl->tpl_vars['data']->value['base_url'];?>
playlist">Administrator</a></li>  
            <li class="active"><?php if ($_smarty_tpl->tpl_vars['data']->value['action']=='update'){?>Update<?php }else{ ?>Add<?php }?> Playlist</li>      
        </ol>
    </div>

    <?php if ($_smarty_tpl->tpl_vars['data']->value['message']!=''){?>
    <div class="span12">
        <div class="alert alert-info">
            <?php echo $_smarty_tpl->tpl_vars['data']->value['message'];?>

        </div>
    </div>
    <?php }?>

    <div class="content">
        <div class="row">
            <div class="col-md-12">
                <div class="box">
                    <div class="box-title">
                        <h3>Add Manage Bar</h3>
                    </div>
                    <div class="box-body">
						<form role="form" id="frmbar" action="<?php echo $_smarty_tpl->tpl_vars['data']->value['admin_url'];?>
bar/<?php echo $_smarty_tpl->tpl_vars['data']->value['action'];?>
" method="post" enctype="multipart/form-data">
								<input type="hidden" name="iOwnerId" value='<?php echo $_smarty_tpl->tpl_vars['data']->value['barOwnerDetail']['iOwnerId'];?>
'>
								<input type="hidden" id="db_admin_email" value='<?php echo $_smarty_tpl->tpl_vars['data']->value['barOwnerDetail']['vEmail'];?>
'>

								<div class="form-group">
									<label>Bar - Pub Owner<sup><span style="color:#CC2131">*</span></sup></label>
									<select class="form-control" name="iOwnerId" id="iOwnerId" >
										<option value="">-- Select Owner --</option>
										<?php if (isset($_smarty_tpl->tpl_vars['smarty']->value['section']['i'])) unset($_smarty_tpl->tpl_vars['smarty']->value['section']['i']);
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['name'] = 'i';
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['loop'] = is_array($_loop=$_smarty_tpl->tpl_vars['barOweners']->value) ? count($_loop) : max(0, (int)$_loop); unset($_loop);
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['show'] = true;
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['max'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['loop'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['step'] = 1;
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['start'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['step'] > 0 ? 0 : $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['loop']-1;
if ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['show']) {
    $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['total'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['loop'];
    if ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['total'] == 0)
        $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['show'] = false;
} else
    $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['total'] = 0;
if ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['show']):

            for ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['index'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['start'], $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['iteration'] = 1;
                 $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['iteration'] <= $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['total'];
                 $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['index'] += $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['step'], $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['iteration']++):
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['rownum'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['iteration'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['index_prev'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['index'] - $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['step'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['index_next'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['index'] + $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['step'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['first']      = ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['iteration'] == 1);
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['last']       = ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['iteration'] == $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['total']);
?>
										<option <?php if ($_smarty_tpl->tpl_vars['barOweners']->value[$_smarty_tpl->getVariable('smarty')->value['section']['i']['index']]['iOwnerId']==$_smarty_tpl->tpl_vars['data']->value['barOwnerDetail']['iOwnerId']){?>selected="selected"<?php }?>value="<?php echo $_smarty_tpl->tpl_vars['barOweners']->value[$_smarty_tpl->getVariable('smarty')->value['section']['i']['index']]['iOwnerId'];?>
"><?php echo $_smarty_tpl->tpl_vars['barOweners']->value[$_smarty_tpl->getVariable('smarty')->value['section']['i']['index']]['vFirstName'];?>
 <?php echo $_smarty_tpl->tpl_vars['barOweners']->value[$_smarty_tpl->getVariable('smarty')->value['section']['i']['index']]['vLastName'];?>
</option>
										<?php endfor; endif; ?>
									</select>
								</div>

								<div class="form-group">
									<label class="control-label" for="first-name">Bar Name<sup><span style="color:#CC2131">*</span></sup></label>
									<input type="text" class="form-control" id="vBarName" name="vBarName" value="<?php echo $_smarty_tpl->tpl_vars['data']->value['barOwnerDetail']['vBarName'];?>
">
								</div>

								<div class="form-group">
									<label class="control-label" for="first-name">About Bar<sup><span style="color:#CC2131">*</span></sup></label>
									<textarea class="form-control" id="tAboutBar" name="tAboutBar" value="<?php echo $_smarty_tpl->tpl_vars['data']->value['barOwnerDetail']['tAboutBar'];?>
"></textarea>
								</div>

								<div class="form-group">
									<label class="control-label" for="first-name">More Information<sup><span style="color:#CC2131">*</span></sup></label>
									<textarea class="form-control" id="tMoreInformation" name="tMoreInformation" value="<?php echo $_smarty_tpl->tpl_vars['data']->value['barOwnerDetail']['tMoreInformation'];?>
"></textarea>
								</div>

								<div class="form-group">
									<label class="control-label" for="first-name">Highlight<sup><span style="color:#CC2131">*</span></sup></label>
									<textarea class="form-control" id="tHighlight" name="tHighlight" value="<?php echo $_smarty_tpl->tpl_vars['data']->value['barOwnerDetail']['tHighlight'];?>
"></textarea>
								</div>

								<div class="form-group">
									<label class="control-label" for="first-name">Address<sup><span style="color:#CC2131">*</span></sup></label>
									<textarea class="form-control" id="tAddress" name="tAddress" value="<?php echo $_smarty_tpl->tpl_vars['data']->value['barOwnerDetail']['tAddress'];?>
"></textarea>
								</div>

								<div class="form-group">
									<label class="control-label" for="first-name">Latitude<sup><span style="color:#CC2131">*</span></sup></label>
									<input type="text" class="form-control" id="vlatitude" name="vlatitude" value="<?php echo $_smarty_tpl->tpl_vars['data']->value['barOwnerDetail']['vlatitude'];?>
">
								</div>

								<div class="form-group">
									<label class="control-label" for="first-name">Longitude<sup><span style="color:#CC2131">*</span></sup></label>
									<input type="text" class="form-control" id="vLongitude" name="vLongitude" value="<?php echo $_smarty_tpl->tpl_vars['data']->value['barOwnerDetail']['vLongitude'];?>
">
								</div>

								<div class="form-group">
									<label>Open and Close Time<sup><span style="color:#CC2131">*</span></sup></label>
									<select class="form-control" name="iOwnerId" id="iOwnerId" >										
										<?php if (isset($_smarty_tpl->tpl_vars['smarty']->value['section']['foo'])) unset($_smarty_tpl->tpl_vars['smarty']->value['section']['foo']);
$_smarty_tpl->tpl_vars['smarty']->value['section']['foo']['name'] = 'foo';
$_smarty_tpl->tpl_vars['smarty']->value['section']['foo']['start'] = (int)00;
$_smarty_tpl->tpl_vars['smarty']->value['section']['foo']['loop'] = is_array($_loop=12) ? count($_loop) : max(0, (int)$_loop); unset($_loop);
$_smarty_tpl->tpl_vars['smarty']->value['section']['foo']['show'] = true;
$_smarty_tpl->tpl_vars['smarty']->value['section']['foo']['max'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['foo']['loop'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['foo']['step'] = 1;
if ($_smarty_tpl->tpl_vars['smarty']->value['section']['foo']['start'] < 0)
    $_smarty_tpl->tpl_vars['smarty']->value['section']['foo']['start'] = max($_smarty_tpl->tpl_vars['smarty']->value['section']['foo']['step'] > 0 ? 0 : -1, $_smarty_tpl->tpl_vars['smarty']->value['section']['foo']['loop'] + $_smarty_tpl->tpl_vars['smarty']->value['section']['foo']['start']);
else
    $_smarty_tpl->tpl_vars['smarty']->value['section']['foo']['start'] = min($_smarty_tpl->tpl_vars['smarty']->value['section']['foo']['start'], $_smarty_tpl->tpl_vars['smarty']->value['section']['foo']['step'] > 0 ? $_smarty_tpl->tpl_vars['smarty']->value['section']['foo']['loop'] : $_smarty_tpl->tpl_vars['smarty']->value['section']['foo']['loop']-1);
if ($_smarty_tpl->tpl_vars['smarty']->value['section']['foo']['show']) {
    $_smarty_tpl->tpl_vars['smarty']->value['section']['foo']['total'] = min(ceil(($_smarty_tpl->tpl_vars['smarty']->value['section']['foo']['step'] > 0 ? $_smarty_tpl->tpl_vars['smarty']->value['section']['foo']['loop'] - $_smarty_tpl->tpl_vars['smarty']->value['section']['foo']['start'] : $_smarty_tpl->tpl_vars['smarty']->value['section']['foo']['start']+1)/abs($_smarty_tpl->tpl_vars['smarty']->value['section']['foo']['step'])), $_smarty_tpl->tpl_vars['smarty']->value['section']['foo']['max']);
    if ($_smarty_tpl->tpl_vars['smarty']->value['section']['foo']['total'] == 0)
        $_smarty_tpl->tpl_vars['smarty']->value['section']['foo']['show'] = false;
} else
    $_smarty_tpl->tpl_vars['smarty']->value['section']['foo']['total'] = 0;
if ($_smarty_tpl->tpl_vars['smarty']->value['section']['foo']['show']):

            for ($_smarty_tpl->tpl_vars['smarty']->value['section']['foo']['index'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['foo']['start'], $_smarty_tpl->tpl_vars['smarty']->value['section']['foo']['iteration'] = 1;
                 $_smarty_tpl->tpl_vars['smarty']->value['section']['foo']['iteration'] <= $_smarty_tpl->tpl_vars['smarty']->value['section']['foo']['total'];
                 $_smarty_tpl->tpl_vars['smarty']->value['section']['foo']['index'] += $_smarty_tpl->tpl_vars['smarty']->value['section']['foo']['step'], $_smarty_tpl->tpl_vars['smarty']->value['section']['foo']['iteration']++):
$_smarty_tpl->tpl_vars['smarty']->value['section']['foo']['rownum'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['foo']['iteration'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['foo']['index_prev'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['foo']['index'] - $_smarty_tpl->tpl_vars['smarty']->value['section']['foo']['step'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['foo']['index_next'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['foo']['index'] + $_smarty_tpl->tpl_vars['smarty']->value['section']['foo']['step'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['foo']['first']      = ($_smarty_tpl->tpl_vars['smarty']->value['section']['foo']['iteration'] == 1);
$_smarty_tpl->tpl_vars['smarty']->value['section']['foo']['last']       = ($_smarty_tpl->tpl_vars['smarty']->value['section']['foo']['iteration'] == $_smarty_tpl->tpl_vars['smarty']->value['section']['foo']['total']);
?>
										<option value="<?php echo $_smarty_tpl->getVariable('smarty')->value['section']['foo']['index'];?>
"><?php echo $_smarty_tpl->getVariable('smarty')->value['section']['foo']['index'];?>
</option>
										<?php endfor; endif; ?>
									</select>
								</div>

								

								<div class="form-group">
									<label>Features<sup><span style="color:#CC2131">*</span></sup></label>
									<select class="form-control" name="eFeatured" id="eFeatured" >
										<option value="">-- Select Features --</option>
										<?php if (isset($_smarty_tpl->tpl_vars['smarty']->value['section']['i'])) unset($_smarty_tpl->tpl_vars['smarty']->value['section']['i']);
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['name'] = 'i';
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['loop'] = is_array($_loop=$_smarty_tpl->tpl_vars['eFeatured']->value) ? count($_loop) : max(0, (int)$_loop); unset($_loop);
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['show'] = true;
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['max'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['loop'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['step'] = 1;
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['start'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['step'] > 0 ? 0 : $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['loop']-1;
if ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['show']) {
    $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['total'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['loop'];
    if ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['total'] == 0)
        $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['show'] = false;
} else
    $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['total'] = 0;
if ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['show']):

            for ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['index'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['start'], $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['iteration'] = 1;
                 $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['iteration'] <= $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['total'];
                 $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['index'] += $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['step'], $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['iteration']++):
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['rownum'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['iteration'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['index_prev'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['index'] - $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['step'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['index_next'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['index'] + $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['step'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['first']      = ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['iteration'] == 1);
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['last']       = ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['iteration'] == $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['total']);
?>
										<option <?php if ($_smarty_tpl->tpl_vars['eFeatured']->value[$_smarty_tpl->getVariable('smarty')->value['section']['i']['index']]==$_smarty_tpl->tpl_vars['data']->value['barOwnerDetail']['eFeatured']){?>selected="selected"<?php }?>value="<?php echo $_smarty_tpl->tpl_vars['eFeatured']->value[$_smarty_tpl->getVariable('smarty')->value['section']['i']['index']];?>
"><?php echo $_smarty_tpl->tpl_vars['eFeatured']->value[$_smarty_tpl->getVariable('smarty')->value['section']['i']['index']];?>
</option>
										<?php endfor; endif; ?>
									</select>
								</div>

								<?php if ($_smarty_tpl->tpl_vars['data']->value['action']=='create'){?>
								<button type="submit" id="btn-save" class="btn btn-primary" onclick="validate();">Save</button>
								<?php }else{ ?>
									<button type="submit" id="btn-save" class="btn btn-primary" onclick="validate();">Save Change</button>
								<?php }?>
								<button type="button" class="btn btn-primary" onclick="returnme();">Cancel</button>
								<span  id="loader" style="float: left;padding-right:15px;display: block;"></span>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<script type="text/javascript">
	function returnme()
	{
	    window.location.href = base_url+'bar_pub_owner';
	}

	$(document).ready(function() {
	    $('#frmbar').bootstrapValidator({
	        message: 'This value is not valid',
	        icon: {
	            valid: 'glyphicon glyphicon-ok',
	            invalid: 'glyphicon glyphicon-remove',
	            validating: 'glyphicon glyphicon-refresh'
	        },
	        fields: {
	            barOweners: {
	                validators: {
	                    notEmpty: { message: 'Owner Name is required and can\'t be empty' },
	                     
	                }
	            },
	            vBarName: {
	                validators: {
	                    notEmpty: { message: 'Bar Name is required and can\'t be empty' },
	                     
	                }
	            },
	            tAboutBar: {
	                validators: {
	                    notEmpty: { message: 'About Bar is required and can\'t be empty' },
	                     
	                }
	            },
	            tMoreInformation: {
	                validators: {
	                    notEmpty: { message: 'More Information is required and can\'t be empty' },
	                     
	                }
	            },
	            tHighlight: {
	                validators: {
	                    notEmpty: { message: 'Highlight is required and can\'t be empty' },
	                     
	                }
	            },
	            tAddress: {
	                validators: {
	                    notEmpty: { message: 'Address is required and can\'t be empty' },
	                     
	                }
	            },
	            vlatitude: {
	                validators: {
	                    notEmpty: { message: 'Latitude is required and can\'t be empty' },    
	                }  
	            },
	            vLongitude: {
	                validators: {
	                    notEmpty: { message: 'Longitude is required and can\'t be empty'},       
	                }  
	            },
	            eFeatured: {
	                validators: {
	                    notEmpty: {  message: 'Features is required and can\'t be empty'}
	                }
	            }
	        }
	    });
	});
</script>
<?php }} ?>