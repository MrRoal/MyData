<?php /* Smarty version Smarty-3.1.11, created on 2015-11-02 19:59:31
         compiled from "application/views/templates/admin/left_sidemenu.tpl" */ ?>
<?php /*%%SmartyHeaderCode:75142319456375e333d7fe9-99524405%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'd6f3faa166efef998ae9f15af61b9fca093401f8' => 
    array (
      0 => 'application/views/templates/admin/left_sidemenu.tpl',
      1 => 1446460627,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '75142319456375e333d7fe9-99524405',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'data' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.11',
  'unifunc' => 'content_56375e334163b2_72859900',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56375e334163b2_72859900')) {function content_56375e334163b2_72859900($_smarty_tpl) {?><div class="leftside">
    <div class="sidebar">
        <ul class="sidebar-menu" style="padding-top:10px;">
            <li class="<?php if ($_smarty_tpl->tpl_vars['data']->value['menuAction']=='Dashboard'){?>active<?php }?>">
                <a href="<?php echo $_smarty_tpl->tpl_vars['data']->value['admin_url'];?>
">
                    <i class="fa fa-home"></i> <span>Dashboard</span>
                </a>
            </li>

            <li class="<?php if ($_smarty_tpl->tpl_vars['data']->value['menuAction']=='Administrator'){?>active<?php }?>">
                <a href="<?php echo $_smarty_tpl->tpl_vars['data']->value['admin_url'];?>
admin_management">
                    <i class="fa fa-fw fa-user"></i> <span>Admin Management</span>
                </a>
            </li>

            <li class="sub-nav <?php if ($_smarty_tpl->tpl_vars['data']->value['menuAction']=='barOwner'||$_smarty_tpl->tpl_vars['data']->value['menuAction']=='manageBar'){?>active<?php }?>">
            
                <a href="#fakelink">
                    <i class="fa fa-fw fa-glass"></i>
                    <i class="fa fa-angle-right pull-right"></i>
                    Manage Bar / Pub
                </a>
                <ul class="sub-menu" <?php if ($_smarty_tpl->tpl_vars['data']->value['menuAction']=='barOwner'||$_smarty_tpl->tpl_vars['data']->value['menuAction']=='manageBar'){?>style="display: block;"<?php }?>>
                    <li class="<?php if ($_smarty_tpl->tpl_vars['data']->value['menuAction']=='barOwner'){?>active<?php }?>">
                        <a href="<?php echo $_smarty_tpl->tpl_vars['data']->value['admin_url'];?>
bar_pub_owner"><i class="fa fa-fw fa-bar-chart-o"></i>
                        Owners</a>
                    </li>
                    <li class="<?php if ($_smarty_tpl->tpl_vars['data']->value['menuAction']=='manageBar'){?>active<?php }?>">
                        <a href="<?php echo $_smarty_tpl->tpl_vars['data']->value['admin_url'];?>
bar"><i class="fa fa-fw fa-bar-chart-o"></i>
                        Bar / Pub</a>
                    </li>
                </ul>
            </li>

            <li class="<?php if ($_smarty_tpl->tpl_vars['data']->value['menuAction']=='manageUser'){?>active<?php }?>">
                <a href="<?php echo $_smarty_tpl->tpl_vars['data']->value['admin_url'];?>
user">
                    <i class="fa fa-fw fa-users"></i> <span>Manage Users</span>
                </a>
            </li>

            <li class="sub-nav <?php if ($_smarty_tpl->tpl_vars['data']->value['menuAction']=='Statistic'||$_smarty_tpl->tpl_vars['data']->value['menuAction']=='Charts'||$_smarty_tpl->tpl_vars['data']->value['menuAction']=='Configuration'){?>active<?php }?>">
            
                <a href="#fakelink">
                    <i class="fa fa-fw fa-cogs"></i>
                    <i class="fa fa-angle-right pull-right"></i>
                    General Settings
                </a>
                <ul class="sub-menu" <?php if ($_smarty_tpl->tpl_vars['data']->value['menuAction']=='FaqCategory'||$_smarty_tpl->tpl_vars['data']->value['menuAction']=='Faq'||$_smarty_tpl->tpl_vars['data']->value['menuAction']=='emailTemplate'||$_smarty_tpl->tpl_vars['data']->value['menuAction']=='ContactUs'||$_smarty_tpl->tpl_vars['data']->value['menuAction']=='Configuration'){?>style="display: block;"<?php }?>>
                    <li class="<?php if ($_smarty_tpl->tpl_vars['data']->value['menuAction']=='FaqCategory'){?>active<?php }?>">
                        <a href="<?php echo $_smarty_tpl->tpl_vars['data']->value['admin_url'];?>
faqcategory"><i class="fa fa-fw fa-columns"></i>
                        Manage FAQ Categories</a>
                    </li>
                    <li class="<?php if ($_smarty_tpl->tpl_vars['data']->value['menuAction']=='Faq'){?>active<?php }?>">
                        <a href="<?php echo $_smarty_tpl->tpl_vars['data']->value['admin_url'];?>
faq"><i class="fa fa-fw fa-file-text-o"></i>
                        Manage FAQ</a>
                    </li>
                    <li class="<?php if ($_smarty_tpl->tpl_vars['data']->value['menuAction']=='emailTemplate'){?>active<?php }?>">
                        <a href="<?php echo $_smarty_tpl->tpl_vars['data']->value['admin_url'];?>
emailtemplate"><i class="fa fa-fw fa-clipboard"></i>
                        Email Templates</a>
                    </li>
                    <li class="<?php if ($_smarty_tpl->tpl_vars['data']->value['menuAction']=='ContactUs'){?>active<?php }?>">
                        <a href="<?php echo $_smarty_tpl->tpl_vars['data']->value['admin_url'];?>
contact_us"><i class="fa fa-fw fa-envelope-o"></i>
                        Contact US / Feedback</a>
                    </li>
                    <li class="<?php if ($_smarty_tpl->tpl_vars['data']->value['menuAction']=='Configuration'){?>active<?php }?>">
                        <a href="<?php echo $_smarty_tpl->tpl_vars['data']->value['admin_url'];?>
configuration"><i class="fa fa-fw fa-cog"></i>
                        Settings</a>
                    </li>
                </ul>
            </li>

        </ul>
    </div>
</div><?php }} ?>