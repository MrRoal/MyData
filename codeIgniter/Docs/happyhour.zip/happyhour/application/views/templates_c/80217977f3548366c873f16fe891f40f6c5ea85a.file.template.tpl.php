<?php /* Smarty version Smarty-3.1.11, created on 2015-11-02 20:12:59
         compiled from "application/views/templates/template.tpl" */ ?>
<?php /*%%SmartyHeaderCode:17562098035637615b0291e7-36574558%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '80217977f3548366c873f16fe891f40f6c5ea85a' => 
    array (
      0 => 'application/views/templates/template.tpl',
      1 => 1446039866,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '17562098035637615b0291e7-36574558',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'data' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.11',
  'unifunc' => 'content_5637615b090c33_96760865',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5637615b090c33_96760865')) {function content_5637615b090c33_96760865($_smarty_tpl) {?><!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
    
    <title> ::: Happy Hour ::: </title>
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo $_smarty_tpl->tpl_vars['data']->value['base_url'];?>
assets/frontend/images/favicon.ico">
    <link href="<?php echo $_smarty_tpl->tpl_vars['data']->value['front_css'];?>
theme-red.css" rel="stylesheet" type="text/css">
    <link href="<?php echo $_smarty_tpl->tpl_vars['data']->value['front_css'];?>
style.css" rel="stylesheet" type="text/css">
    <link href="<?php echo $_smarty_tpl->tpl_vars['data']->value['front_css'];?>
animate.css" rel="stylesheet" type="text/css">
    <script src="https://maps.googleapis.com/maps/api/js?v=3.exp&sensor=false&libraries=places"></script>
    <link href='http://fonts.googleapis.com/css?family=Raleway:400,500,600,700|Montserrat:400,700' rel='stylesheet' type='text/css'>
    <script type="text/javascript" src="<?php echo $_smarty_tpl->tpl_vars['data']->value['front_js'];?>
jquery.min.js"></script>
    <script>
        var base_url = '<?php echo $_smarty_tpl->tpl_vars['data']->value['base_url'];?>
';
        var front_image = '<?php echo $_smarty_tpl->tpl_vars['data']->value['front_image'];?>
';
        var iMemberId = '<?php echo $_smarty_tpl->tpl_vars['data']->value['userdata']['front_user']['iMemberId'];?>
';
        var FB_APPID = '<?php echo $_smarty_tpl->tpl_vars['data']->value['FB_APPID'];?>
';
        var base_upload = '<?php echo $_smarty_tpl->tpl_vars['data']->value['base_upload'];?>
';
    </script>

   
</head>
<body>
    <?php echo $_smarty_tpl->getSubTemplate ($_smarty_tpl->tpl_vars['data']->value['tpl_name'], $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>


<script type="text/javascript" src="<?php echo $_smarty_tpl->tpl_vars['data']->value['front_js'];?>
jquery.uniform.min.js"></script>
<script type="text/javascript" src="<?php echo $_smarty_tpl->tpl_vars['data']->value['front_js'];?>
jquery.datetimepicker.js"></script>
<script type="text/javascript" src="<?php echo $_smarty_tpl->tpl_vars['data']->value['front_js'];?>
jquery.slicknav.min.js"></script>
<script type="text/javascript" src="<?php echo $_smarty_tpl->tpl_vars['data']->value['front_js'];?>
infobox.js"></script>
<script type="text/javascript" src="<?php echo $_smarty_tpl->tpl_vars['data']->value['front_js'];?>
wow.min.js"></script>
<script type="text/javascript" src="<?php echo $_smarty_tpl->tpl_vars['data']->value['front_js'];?>
search.js"></script>
<script type="text/javascript" src="<?php echo $_smarty_tpl->tpl_vars['data']->value['front_js'];?>
scripts.js"></script>

</body>
</html><?php }} ?>