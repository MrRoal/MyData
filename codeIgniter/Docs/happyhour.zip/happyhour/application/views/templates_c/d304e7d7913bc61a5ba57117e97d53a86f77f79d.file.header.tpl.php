<?php /* Smarty version Smarty-3.1.11, created on 2015-11-02 20:12:59
         compiled from "application/views/templates/header.tpl" */ ?>
<?php /*%%SmartyHeaderCode:2181933895637615b0aa1a5-52515743%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'd304e7d7913bc61a5ba57117e97d53a86f77f79d' => 
    array (
      0 => 'application/views/templates/header.tpl',
      1 => 1446040446,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2181933895637615b0aa1a5-52515743',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'data' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.11',
  'unifunc' => 'content_5637615b0afcb0_81444071',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5637615b0afcb0_81444071')) {function content_5637615b0afcb0_81444071($_smarty_tpl) {?><header class="header" role="banner">
    <div class="wrap">
        <!-- Logo -->
        <div class="logo">
            <a href="<?php echo $_smarty_tpl->tpl_vars['data']->value['base_url'];?>
" style="font-family:Lato,serif;" title="Happy Hopur"><img src="" alt="Happy Hopur"/></a>
        </div>
        <!-- //Logo -->

        <!-- Main Nav -->
        <nav role="navigation" class="main-nav">
            <ul>
            </ul>
        </nav>
        <!-- //Main Nav -->
    </div>
</header><?php }} ?>