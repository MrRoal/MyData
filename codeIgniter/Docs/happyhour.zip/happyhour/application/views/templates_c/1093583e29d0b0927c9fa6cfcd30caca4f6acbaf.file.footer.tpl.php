<?php /* Smarty version Smarty-3.1.11, created on 2015-11-02 20:12:59
         compiled from "application/views/templates/footer.tpl" */ ?>
<?php /*%%SmartyHeaderCode:12623915095637615b0b27f0-57247193%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '1093583e29d0b0927c9fa6cfcd30caca4f6acbaf' => 
    array (
      0 => 'application/views/templates/footer.tpl',
      1 => 1446040492,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '12623915095637615b0b27f0-57247193',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.11',
  'unifunc' => 'content_5637615b0b3d57_63921733',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5637615b0b3d57_63921733')) {function content_5637615b0b3d57_63921733($_smarty_tpl) {?><footer class="footer black" role="contentinfo">
    <div class="wrap">
        
    </div>
</footer>
    <?php }} ?>