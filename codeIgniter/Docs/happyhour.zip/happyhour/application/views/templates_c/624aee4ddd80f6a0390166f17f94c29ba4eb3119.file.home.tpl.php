<?php /* Smarty version Smarty-3.1.11, created on 2015-11-02 20:12:59
         compiled from "application/views/templates/home.tpl" */ ?>
<?php /*%%SmartyHeaderCode:9836820235637615b095268-37180277%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '624aee4ddd80f6a0390166f17f94c29ba4eb3119' => 
    array (
      0 => 'application/views/templates/home.tpl',
      1 => 1446040356,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '9836820235637615b095268-37180277',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'data' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.11',
  'unifunc' => 'content_5637615b0a74e9_80639791',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5637615b0a74e9_80639791')) {function content_5637615b0a74e9_80639791($_smarty_tpl) {?><!-- //Header -->
<?php echo $_smarty_tpl->getSubTemplate ('header.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

<!-- Main -->
<script type="text/javascript" src="<?php echo $_smarty_tpl->tpl_vars['data']->value['front_js'];?>
jquery.js"></script>
<script type="text/javascript" src="<?php echo $_smarty_tpl->tpl_vars['data']->value['front_js'];?>
skdslider.min.js"></script>

<main class="main" role="main">
	<div class="services iconic white">
		<div class="wrap">
		<div class="boxsecdivd app-left">
			<div class="one-third wow fadeIn fullwidht">
				<span class="circle"><img src="<?php echo $_smarty_tpl->tpl_vars['data']->value['base_upload'];?>
icon/convience.png"></img><!-- <span class="ico pig"></span> --></span>
				<h3>Happy Hour! Coming Soon!</h3>
			</div>
		</div>
	</div>
</main>
<!-- //Main -->
<!-- Footer -->
<?php echo $_smarty_tpl->getSubTemplate ('footer.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>
<?php }} ?>