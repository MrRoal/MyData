<?php
include("../includes/configuration.php");
//echo GOOGLE_API_KEY;exit;
?>