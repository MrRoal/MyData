<?php
if(strpos($_SERVER["HTTP_HOST"],"localhost") >= 0 || strpos($_SERVER["HTTP_HOST"],"192.168.1") >= 0)
{
	$tconfig["tsite_folder"] = "/~techiest/php/pushnotification";
	$tconfig["tsite_folder1"] = "/home/techiest/public_html/php/pushnotification";
}	
else
{
	$tconfig["tsite_folder"]  = "/~techiest/php/pushnotification";
	$tconfig["tsite_folder1"] = "/home/techiest/public_html/php/pushnotification";
}
//echo $tconfig["tsite_folder"];exit;
$tconfig["tsite_admin"] = "admin";
$tconfig["tsite_url"] = "http://".$_SERVER["HTTP_HOST"].$tconfig["tsite_folder"];


$site_path	= $_SERVER["DOCUMENT_ROOT"].$tconfig["tsite_folder"];
$site_url = $tconfig["tsite_url"];


$tconfig["tpanel_url"] = "http://".$_SERVER["HTTP_HOST"]."/".$tconfig["tsite_folder"]."/".$tconfig["tsite_admin"];

$admin_url = $tconfig["tpanel_url"];
$admin_path=$_SERVER["DOCUMENT_ROOT"].$tconfig["tsite_folder"]."/".$tconfig["tsite_admin"];

define('PUSHURL', $tconfig["tsite_url"].'/pushnotify/');
define('ANDROID_PUSHURL', $tconfig["tsite_url"].'/pushnotify_Android/');
//p($_REQUEST);exit;
if(!empty($_REQUEST['project'])){
	$projectName = $_REQUEST['project'];	
}

/*if(!empty($_REQUEST['googleApiKey'])){
	$googleApiKey = $_REQUEST['googleApiKey'];
}*/
$con=mysqli_connect("localhost","techiest_allpush","gFC6pB0a.Q^n","techiest_all_pushnotification");
$result = mysqli_query($con,"SELECT c.CertificateId,c.AppId,a.AppId,a.vProjectName,a.tGoogleApi FROM Apps a LEFT JOIN Certificates c ON c.AppId = a.AppId WHERE a.vProjectName = '".$projectName."'");
$row = mysqli_fetch_array($result);

//echo '<pre>hi';print_r($row);exit;

define('APPID', $row['AppId']);
define('CERTID', $row['CertificateId']);
$googleApiKey = $row['tGoogleApi'];

//echo $googleApiKey;exit;

//define('APPID', '1');
//define('CERTID', '1');


//defined( '_TEXEC' ) or die( 'Restricted access' );
//echo $tconfig["tsite_folder1"];exit;
$parts = explode( DS, TPATH_BASE );
define( 'TPATH_ROOT',			$tconfig["tsite_folder1"] );

define( 'TPATH_ADMINISTRATOR', 	TPATH_ROOT.DS.'admin' );
define( 'TPATH_LIBRARIES', 		TPATH_ROOT.DS.'libraries' );
define( 'TPATH_CLASS_DATABASE', TPATH_ROOT.DS.'libraries'.DS.'database/' );
define( 'TPATH_CLASS_GEN', 		TPATH_ROOT.DS.'libraries'.DS.'general/' );

$imagemagickinstalldir='/usr/local/bin';
$useimagemagick = "Yes";


if(strpos($_SERVER["HTTP_HOST"],"localhost") >= 0 || strpos($_SERVER["HTTP_HOST"],"192.168.1") >= 0)
{

	define( 'TSITE_SERVER','localhost');
	define( 'TSITE_DB','techiest_all_pushnotification');
	define( 'TSITE_USERNAME','techiest_allpush');
	define( 'TSITE_PASS','gFC6pB0a.Q^n');
	
	/**
	* Database config variables
	*/
	define("DB_HOST", "localhost");
	define("DB_DATABASE", "techiest_all_pushnotification");
	define("DB_USER", "techiest_allpush");
	define("DB_PASSWORD", "gFC6pB0a.Q^n");
	
	/*
	* Google API Key
	*/
	define("GOOGLE_API_KEY", $googleApiKey); // PUSH TEST

}
else
{
	define( 'TSITE_SERVER','localhost');
	define( 'TSITE_DB','techiest_all_pushnotification ');
	define( 'TSITE_USERNAME','techiest_allpush');
	define( 'TSITE_PASS','gFC6pB0a.Q^n');
	/**
	* Database config variables
	*/
	define("DB_HOST", "localhost");
	define("DB_DATABASE", "techiest_all_pushnotification");
	define("DB_USER", "techiest_allpush");
	define("DB_PASSWORD", "gFC6pB0a.Q^n");
	
	/*
	* Google API Key
	*/
	define("GOOGLE_API_KEY", $googleApiKey);
}

//Certificate folder
$certificateFolder = 'certificates';


//Push and Feedback servers
//These urls are stored in mySQL in the CertificateTypes table.

//Date settings. Apple uses UTC dates for Feedback info
date_default_timezone_set('UTC');

function p($var){
	echo "<pre>";
	print_r($var);
	echo "<hr>";
}
?>
